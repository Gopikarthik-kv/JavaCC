package abstractClassCC;

public class ProductOwner extends User {

	public ProductOwner() {

	}

	public ProductOwner(String userName, String password, String name, String role) {
		super(userName, password, name, role);
		// TODO Auto-generated constructor stub
	}

	Boolean allocateBudget(String budgetDetail, Requirement[] requirement) {
		boolean found = false;
		int id = Integer.valueOf(budgetDetail.split(",")[0]);
		float budget = Float.valueOf(budgetDetail.split(",")[1]);
		if (budget < 1)
			return found;
		for (Requirement req : requirement) {
			if (req.getId() == id) {
				found = true;
				req.setBudget(budget);
				break;
			}
		}
		return found;
	}

	Boolean allocatePlanTime(String planTimeDetail, Requirement[] requirement) {
		boolean found = false;
		int id = Integer.valueOf(planTimeDetail.split(",")[0]);
		int planTime = Integer.valueOf(planTimeDetail.split(",")[1]);
		if (planTime < 1)
			return found;
		for (Requirement req : requirement) {
			if (req.getId() == id) {
				found = true;
				req.setPlanTime(planTime);
				break;
			}
		}
		return found;
	}
}
