package abstractClassCC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//Test 2: Check the logic for Allocate budget
public class Main {
	static Requirement[] req = new Requirement[] {};

	public static void main(String[] args) throws IOException {
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		System.out.println("Enter number of user :");
		int arrSize = Integer.parseInt(br.readLine().trim());
		User[] userArr = new User[arrSize];
		int temp = 0;
		String userDetail = null;
		for (temp = 0; temp < userArr.length; temp++) {
			System.out.printf("Enter user %d detail :\n", temp + 1);
			userDetail = br.readLine().trim();
			String[] userDetails = userDetail.split(",");
			userArr[temp] = new User(userDetails[1], userDetails[2], userDetails[0], userDetails[3]);
		}

		int input = 1;
		do {
			System.out.println("1. Login\n2. Exit\nEnter your choice :");
			input = Integer.parseInt(br.readLine().trim());
			if (input == 1) {
				System.out.println("Enter the user name :");
				String userName = br.readLine().trim();
				System.out.println("Enter the password :");
				String pwd = br.readLine().trim();

				boolean match = false;
				temp = 0;
				for (temp = 0; temp < userArr.length; temp++) {
					if (userArr[temp].getUserName().equalsIgnoreCase(userName)
							&& userArr[temp].getPassword().equals(pwd)) {
						match = true;
						break;
					}
				}
				if (match) {
					userArr[temp].display(br, req, userArr);
				} else {
					br.close();
					return;
				}
			} else {
				br.close();
				return;

			}
		} while (input != 2);
		br.close();
	}

}

