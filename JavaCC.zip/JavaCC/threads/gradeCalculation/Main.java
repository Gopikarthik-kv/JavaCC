package gradeCalculation;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of Threads:");
		int threadCount = Integer.parseInt(input.nextLine());
		GradeCalculator[] threads = new GradeCalculator[threadCount];

		for (int x = 0; x < threadCount; x++) {
			System.out.println("Enter the String:");
			String inp = input.nextLine();
			String[] arr = inp.substring(inp.indexOf(":") + 1).split(":");
			int[] marks = new int[arr.length];
			for (int temp = 0; temp < arr.length; temp++)
				marks[temp] = Integer.parseInt(arr[temp]);
			threads[x] = new GradeCalculator(inp.split(":")[0], marks);
			threads[x].start();
		}

//		for (int x = 0; x < threadCount; x++) {
//			try {
//				threads[x].join();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}

		for (int x = 0; x < threadCount; x++) {
			System.out.println(threads[x].getStudName() + ":" + threads[x].getResult());

		}

		input.close();

	}

}
