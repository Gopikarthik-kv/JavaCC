package searchbyFirstName;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int iter = 1;
		boolean anotherUsr = true;
		UserDAO userDAO = new UserDAO();
		do {
			System.out.println("Enter user " + iter + " detail:");
			String[] input = in.nextLine().split(",");
			userDAO.createUser(new User(iter, input[0], input[1], input[2], input[3], new Contact(iter, input[4], input[5])));
			System.out.println("Do you want to create another user?(yes/no)");
			if (in.nextLine().equalsIgnoreCase("no")) {
				in.close();
				break;
			}
			iter++;
		} while (anotherUsr);
		System.out.println("Enter the first name to search:");
		List<User> users = userDAO.findByFirstName(in.nextLine());
		System.out.println("Id Firstname Lastname Mobilenumber Email ID");
		for (User user : users) {
			System.out.println(user.getId() + " " + user.getFirstName() + " " + user.getLastName() + " "
					+ user.getContact().getMobileNumber() + " " + user.getContact().getEmailId());
		}
	}

}
