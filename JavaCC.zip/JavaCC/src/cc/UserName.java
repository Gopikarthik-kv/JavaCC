package cc;

import java.util.Scanner;

public class UserName {
	public static void main(String[] args) {
		int numCSE;
		int numECE;
		int numMECH;
		Scanner in = new Scanner(System.in);

		System.out.println("Enter the no of students placed in CSE");
		numCSE = Integer.parseInt(in.nextLine());

		System.out.println("Enter the no of students placed in ECE");
		numECE = Integer.parseInt(in.nextLine());

		System.out.println("Enter the no of students placed in MECH");
		numMECH = Integer.parseInt(in.nextLine());

		in.close();

		if ((numCSE == numECE) && (numCSE == numMECH) && (numECE == numMECH)) {
			System.out.println("None of the department has got the highest placement");
		} else if (Math.min(Math.min(numCSE, numECE), numMECH) < 0) {
			System.out.println("Input is Invalid");
		} else {
			System.out.println("Highest placement");
			if (Math.max(Math.max(numCSE, numECE), numMECH) == numCSE) {
				System.out.println("CSE");
			}

			if (Math.max(Math.max(numCSE, numECE), numMECH) == numECE) {
				System.out.println("ECE");
			}

			if (Math.max(Math.max(numCSE, numECE), numMECH) == numMECH) {
				System.out.println("MECH");
			}
		}
	}
}

//
//public class UserName {
//
//	public static void main(String[] args) {
//
//		int numPizza;
//		int numPuffs;
//		int numCool;
//		int totalPrice;
//
//		Scanner in = new Scanner(System.in);
//
//		System.out.println("Enter the no of pizzas bought");
//		numPizza = Integer.parseInt(in.nextLine());
//
//		System.out.println("Enter the no of puffs bought");
//		numPuffs = Integer.parseInt(in.nextLine());
//
//		System.out.println("Enter the no of cool drinks bought");
//		numCool = Integer.parseInt(in.nextLine());
//
//		in.close();
//
//		totalPrice = numPizza * 100 + numPuffs * 20 + numCool * 10;
//		System.out.println("Bill Details" + "\n" + "No of pizzas" + "\n" + numPizza + "\n" + "No of puffs" + "\n"
//				+ numPuffs + "\n" + "No of cool drinks" + "\n" + numCool + "\n" + "Total price" + "\n" + totalPrice + "\n" + "ENJOY THE SHOW!!!");
//
//	}
//
//}
