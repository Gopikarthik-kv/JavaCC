package inactiveUsers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DbConnection {

	private static Connection con = null;

	public static Connection getConnection()
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		ResourceBundle rb = ResourceBundle.getBundle("mysql");
		String url = rb.getString("DB_URL");
		String username = rb.getString("DB_USERNAME");
		String password = rb.getString("DB_PASSWORD");
		con = DriverManager.getConnection(url, username, password);

		return con;
	}

}
