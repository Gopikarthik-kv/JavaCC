package updateItemPrice;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class ItemDAO {
	public List<Item> getAllItems() {
		List<Item> items = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT ID,name,price FROM item ORDER BY ID DESC");
			while (rs.next()) {
				items.add(
						new Item(rs.getString("ID"), rs.getString("name"), Double.parseDouble(rs.getString("price"))));
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return items;
	}

	public void updateItemPrice(String item, Double price) {
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE ITEM SET PRICE = '" + price + "' WHERE ID = '" + item + "'");
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
