package cc;

import java.util.*;

public class CarDetails {

	public static void main(String[] args) {
	     
	      String name;
	      Scanner in = new Scanner(System.in);
	     
	      System.out.println("Enter the name");
	      name = in.nextLine();
	            
	      in.close();
	      
	      System.out.printf("Hello %s! Get access to the unique shipping!", name);
	}

}

//public class CarDetails {
//
//	public static void main(String[] args) {
//	     
//	      String carName;
//	      String carNum;
//	      float price;
//	      Scanner in = new Scanner(System.in);
//	     
//	      System.out.println("Enter the car name:");
//	      carName = in.nextLine();
//	      
//	      System.out.println("Enter the car no:");
//	      carNum = in.nextLine();
//	      
//	      System.out.println("Enter the price:");
//	      price = in.nextFloat();
//	            
//	      in.close();
//
//	      System.out.println("Car name:" + carName);
//	      System.out.println("Car no:" + carNum);
//	      System.out.printf("Price:%.2f rs only", price);
//	}
//
//}
