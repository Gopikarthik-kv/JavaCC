package shippingCost;

import java.util.ArrayList;
import java.util.List;

public class ShippingCostThread extends Thread {

	private List<Cargo> cargoList;
	private List<Double> priceList = new ArrayList<>();

	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public List<Cargo> getCargoList() {
		return cargoList;
	}

	public void setCargoList(List<Cargo> cargoList) {
		this.cargoList = cargoList;
	}

	public List<Double> getPriceList() {
		for (Cargo cargo : this.cargoList) {
			if (cargo.getStorageType().equalsIgnoreCase("DRY"))
				priceList.add(cargo.getWeight() * 0.90);
			else if (cargo.getStorageType().equalsIgnoreCase("COLD"))
				priceList.add(cargo.getWeight() * 1.85);
		}
		return priceList;
	}

	public void setPriceList(List<Double> priceList) {
		this.priceList = priceList;
	}

	public ShippingCostThread() {

	}
}
