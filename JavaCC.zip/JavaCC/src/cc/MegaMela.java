package cc;

import java.util.Scanner;

public class MegaMela {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.println("Enter the Amount:");
		double billAmount = in.nextDouble();
		double percentage = (billAmount / 100);

		if (billAmount <= 0) {
			System.out.printf("%.0f is not the valid amount", billAmount);
		}

		else if (billAmount > 0 && billAmount < 1000 && percentage < 10) {
			// double amountSaved = (billAmount*percentage)/100;
			// double amountToBePaid = billAmount-amountSaved;
			System.out.println("Amount you have saved on the bill is:");
			System.out.printf("Rs.%.2f", 0.00);
			System.out.println();
			System.out.println("Amount to be paid:");
			System.out.printf("Rs.%.2f", billAmount);
		} else if (billAmount >= 1000 && billAmount <= 5099 && percentage >= 10 && percentage <= 50) {
			double amountSaved = (billAmount * percentage) / 100;
			double amountToBePaid = billAmount - amountSaved;
			System.out.println("Amount you have saved on the bill is:");
			System.out.printf("Rs.%.2f", amountSaved);
			System.out.println();
			System.out.println("Amount to be paid:");
			System.out.printf("Rs.%.2f", amountToBePaid);
		} else if (billAmount > 5099) {
			double amountSaved = (billAmount * 50) / 100;
			double amountToBePaid = billAmount - amountSaved;
			System.out.println("Amount you have saved on the bill is:");
			System.out.printf("Rs.%.2f", amountSaved);
			System.out.println();
			System.out.println("Amount to be paid:");
			System.out.printf("Rs.%.2f", amountToBePaid);
		}

	}

}
