package cc;

import java.util.*;

public class FuelConsumptionCalc {

	public static void main(String[] args) {
		int ltr;
		int distance;

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the no of liters to fill the tank");
		ltr = Integer.parseInt(in.nextLine());

		if (ltr <= 0) {
			System.out.println( ltr + " is a Invalid Input");
			in.close();
			return;
		}

		System.out.println("Enter the distance covered");
		distance = Integer.parseInt(in.nextLine());

		if (distance <= 0) {
			System.out.println(distance + " is a Invalid Input");
			in.close();
			return;
		}
		
		in.close();
		System.out.printf("Liters/100KM "+"\n%.2f" + "\n", (float) (( (double)ltr / (double)distance) * 100));
		System.out.printf("Miles/gallons "+"\n%.2f", (float)( (distance*0.6214) / (ltr* 0.2642)));
	}

}
