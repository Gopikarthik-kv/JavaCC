package averageAndGradeCalculation;

public class Call {
	private int callid;
	private long calledNumber;
	private float duration;

	public int getCallId() {
		return callid;
	}

	public void setCallId(int callid) {
		this.callid = callid;
	}

	public long getCalledNumber() {
		return calledNumber;
	}

	public void setCalledNumber(Long calledNumber) {
		this.calledNumber = calledNumber;
	}

	public float getDuration() {
		return duration;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}

	public void parseData(String input) {
		String[] arr = input.split(":");
		this.callid = Integer.parseInt(arr[0]);
		this.calledNumber = Long.parseLong(arr[1]);
		this.duration = Float.parseFloat(arr[2]);
	}

}
