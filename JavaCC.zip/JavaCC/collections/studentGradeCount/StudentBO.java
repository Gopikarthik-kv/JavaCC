package studentGradeCount;

//import com.ui.*;
import java.util.*;

public class StudentBO {

	private Map<String, Character> studentMap;

	public Map<String, Character> getStudentMap() {
		return studentMap;
	}

	public void setStudentMap(Map<String, Character> studentMap) {
		this.studentMap = studentMap;
	}

	// This method should add the rollNumber as key and their grades as value into a
	// Map
	public void addStudentDetails(String rollNumber, char securedGrade) {
		this.studentMap.put(rollNumber, securedGrade);
	}

	/*
	 * This method should return the count of students secured the grade which is
	 * passed as the argument. For example: If the map contains the key and value
	 * as: AE1548 A AE1549 A AE1512 C
	 * 
	 * if the grade is A the output should be 2
	 */
	public int findCountofStudents(char grade) {
		int count = 0;
		for (Character stmap : this.studentMap.values()) {
			if (stmap.equals(grade))
				count++;
		}
		// type your logic here
		return count;
	}

}
