package setCategoryAndViewProductDetails;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Shop {

	public Product viewProduct(int pid) {
		Product prd = new Product();
		try {
			DB db = new DB();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT prodId, prodName, prodPrice FROM product WHERE prodId = '" + pid + "'");
			if (rs.next()) {
				System.out.println(rs.getString("prodId"));
				prd.setProdId(Integer.parseInt(rs.getString("prodId")));
				prd.setProdName(rs.getString("prodName"));
				prd.setUnitPrice(Double.parseDouble(rs.getString("prodPrice")));
				prd.setProductCategory();
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return prd;

	}

}