package studentantDepartmentDetail;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		Student stude = createStudent();
		System.out.println("Department id:" + stude.getDepartment().getDid());
		System.out.println("Department name:" + stude.getDepartment().getDname());
		System.out.println("Student id:" + stude.getSid());
		System.out.println("Student name:" + stude.getSname());
	}

	public static Student createStudent() {
		Student stu = new Student();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Department id:");
		stu.getDepartment().setDid(Integer.parseInt(in.nextLine()));
		System.out.println("Enter the Department name:");
		stu.getDepartment().setDname(in.nextLine());
		System.out.println("Enter the Student id:");
		stu.setSid(Integer.parseInt(in.nextLine()));
		System.out.println("Enter the Student name:");
		stu.setSname(in.nextLine());
		in.close();
		return stu;
	}
}
