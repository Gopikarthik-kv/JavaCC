package busyDayoftheweek;

import java.util.List;

public class LMCBO {

	private List<String> appointmentDetailsList;

	public List<String> getAppointmentDetailsList() {
		return appointmentDetailsList;
	}

	public void setAppointmentDetailsList(List<String> appointmentDetailsList) {
		this.appointmentDetailsList = appointmentDetailsList;
	}

	// This method should add the appointmentDay passed as argument into the
	// appointmentDetailsList
	public void addAppointmentDayDetails(String appointmentDay) {
		// type your code here
		this.appointmentDetailsList.add(appointmentDay);
	}

	/*
	 * This method should return the maximum number of appointments made based on
	 * values available in the appointmentDetailsList
	 * 
	 * For Example: if the list contains the following values as
	 * [Saturday,Friday,Saturday,Saturday,Monday] the output should be Saturday
	 * 
	 */
	public int findAppointmentCount(String findDay) {
		int count = 0;
		
		if (appointmentDetailsList.size() == 0)
			return -1;
		
		for (String day : appointmentDetailsList) {
			if (day.equalsIgnoreCase(findDay))
				count++;
		}
		return count;
	}

}
