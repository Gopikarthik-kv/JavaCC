package memberManipulation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Library lib = new Library();
		List<Member> memberList = new ArrayList<>();
		lib.setMemberList(memberList);

		int input = 0;
		do {
			System.out
					.println("1.Add Member\n2.View All Members\n3.Search Member by address\n4.Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			switch (input) {
			case 1:

				System.out.println("Enter the id:");
				int memberId = Integer.parseInt(sc.nextLine());

				System.out.println("Enter the name:");
				String memberName = sc.nextLine();

				System.out.println("Enter the address:");
				String address = sc.nextLine();
				Member mem = new Member(memberId, memberName, address);
				lib.addMember(mem);
				break;
			case 2:

				if (memberList.size() < 1) {
					System.out.println("The list is empty");
					break;
				}

				for (Member memb : lib.getMemberList()) {
					System.out.println("Id:" + memb.getMemberId());
					System.out.println("Name:" + memb.getMemberName());
					System.out.println("Address:" + memb.getAddress());
				}
				break;

			case 3:
				System.out.println("Enter the address:");
				String addres = sc.nextLine();
				if (memberList.size() < 1) {
					System.out.println("The list is empty");
					break;
				}

				List<Member> membList = lib.viewMembersByAddress(addres);
				if (membList.size() < 1) {
					System.out.println("None of the member is from " + addres);
					break;
				}
				for (Member memb : membList) {
					System.out.println("Id:" + memb.getMemberId());
					System.out.println("Name:" + memb.getMemberName());
					System.out.println("Address:" + memb.getAddress());
				}
				break;
			}
		} while (input != 4);
		sc.close();
	}

}
