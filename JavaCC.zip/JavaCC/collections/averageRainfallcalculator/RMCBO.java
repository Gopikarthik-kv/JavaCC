package averageRainfallcalculator;

import java.util.*;
import java.util.Map.Entry;

public class RMCBO {

	private List<Integer> rainfallList;

	public List<Integer> getRainfallList() {
		return rainfallList;
	}

	public void setRainfallList(List<Integer> rainfallList) {
		this.rainfallList = rainfallList;
	}

	// This method should add the recordedRainfall passed as argument into the
	// rainfallList
	public void addRainfallDetails(int recordedRainfall) {
		// type your logic here
		this.rainfallList.add(recordedRainfall);
	}

	/*
	 * This method should return the average rain fall based on the recordedRainfall
	 * values available in the rainfallList averageRainfall can be calculated based
	 * on the following formula averageRainfall= (sum of all values in the list /
	 * size of the list)
	 * 
	 * For Example: if the list contains the following recorded rainfall
	 * [6,15,20,50] averageRainfall= (6+25+20+50) / 4 = 22.75
	 * 
	 */
	public double findAverageRainfallOccured() {
		double averageRainfall = 0;

		if (this.rainfallList.size() > 0) {
			averageRainfall = rainfallList.stream().mapToInt(i -> i.intValue()).sum() / rainfallList.size();
		}
		return averageRainfall;
	}
}
