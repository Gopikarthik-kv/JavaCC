package fruitShop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

@SuppressWarnings("unchecked") // Do not delete this line
public class FruitBasket {
	public static void main(String[] args) {
		System.out.println("Enter the  no of fruits pair you want to store:");
		Scanner sc = new Scanner(System.in);
		int numOfFruits = Integer.parseInt(sc.nextLine());
		HashMap<Integer, String> frtMap = new HashMap<>();
		for (int cnt = 0; cnt < numOfFruits; cnt++) {
			System.out.printf("Enter the key%d\n", cnt + 1);
			int temp = Integer.parseInt(sc.nextLine());
			System.out.printf("Enter the value%d\n", cnt + 1);
			frtMap.put(temp, sc.nextLine());
		}
		sc.close();
		System.out.println("Fruit Details");
		List<Integer> intList = new ArrayList<Integer>(frtMap.keySet());

		Object[] a = frtMap.entrySet().toArray();
		Arrays.sort(a, new Comparator() {
		    public int compare(Object o1, Object o2) {
		        return ((Map.Entry<Integer, String>) o2).getKey()
		                   .compareTo(((Map.Entry<Integer, String>) o1).getKey());
		    }
		});

//		frtMap.entrySet().stream().sorted(Map.Entry.<Integer, String>comparingByKey());

		for (Map.Entry<Integer, String> entry : frtMap.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}

	}

}