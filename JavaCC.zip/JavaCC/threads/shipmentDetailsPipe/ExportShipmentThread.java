package shipmentDetailsPipe;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class ExportShipmentThread extends Thread {
	private List<Shipment> shipmentList = new ArrayList<>();

	StringBuilder shipmentDetails;

	public ExportShipmentThread(List<Shipment> shipmentList) {
		this.shipmentList = shipmentList;
	}

	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public StringBuilder getShipmentDetails() {
		shipmentDetails = new StringBuilder();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		for (Shipment shipment : shipmentList) {
			shipmentDetails.append(shipment.getId()).append("|").append(shipment.getName()).append("|")
					.append(shipment.getBookingNumber()).append("|").append(shipment.getExecutedPlace()).append("|");

			if (shipment.getExecutedDate() != null)
				shipmentDetails.append(formatter.format(shipment.getExecutedDate()));

			shipmentDetails.append("|");

			if (shipment.getDepartureDate() != null)
				shipmentDetails.append(formatter.format(shipment.getDepartureDate()));

			shipmentDetails.append("|");

			if (shipment.getArrivalDate() != null)
				shipmentDetails.append(formatter.format(shipment.getArrivalDate()));

			shipmentDetails.append("|");

			shipmentDetails.append(shipment.getTotalWeight()).append("|").append(shipment.getShipmentStatus())
					.append("|").append(shipment.getCarrierId()).append("\n");
		}
		shipmentDetails.setLength(shipmentDetails.length() - 1);
		return shipmentDetails;
	}

}
