package roleDetails;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class RoleDAO {

	public ArrayList<Role> getAllRoles() {
		ArrayList<Role> roles = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT id,name FROM role ORDER BY name");
			while (rs.next()) {

				roles.add(new Role(Integer.valueOf(rs.getString("id")), rs.getString("name")));
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return roles;
	}

}
