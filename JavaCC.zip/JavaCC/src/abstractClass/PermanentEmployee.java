package abstractClass;

public class PermanentEmployee extends Employee {
	private float pfpercentage;
	private float pfamount;

	public float getPfpercentage() {
		return pfpercentage;
	}

	public void setPfpercentage(float pfpercentage) {
		this.pfpercentage = pfpercentage;
	}

	public float getPfamount() {
		return pfamount;
	}

	public void setPfamount(float pfamount) {
		this.pfamount = pfamount;
	}

	public PermanentEmployee() {

	}

	public PermanentEmployee(String name, float salary, float pfpercentage) {
		super(name, salary);
		this.pfpercentage = pfpercentage;
	}

	public void findNetSalary() {
		this.pfamount = getSalary() * (this.pfpercentage / 100);
		setNetsalary(getSalary() - this.pfamount);
	}

	public static boolean validateInput(float salary, float pfpercentage) {
		boolean valid = true;
		if (salary < 1 || pfpercentage < 0)
			valid = false;
		return valid;

	}
}
