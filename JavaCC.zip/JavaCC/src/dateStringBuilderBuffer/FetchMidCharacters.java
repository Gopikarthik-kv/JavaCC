package dateStringBuilderBuffer;

import java.util.Scanner;

public class FetchMidCharacters {
	public static void main(String[] args) {
		System.out.println("Enter the string:");
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();
		in.close();
		if (str.length() < 3) {
			System.out.println("The string " + str + "is too short");
			return;
		}
		if (!str.matches("[A-Za-z]+")) {
			System.out.println("The string should not have " + findSpecialChar(str));
			return;
		}

		StringBuffer sb = new StringBuffer();
		 if(str.length()%2==0)
		{
			 System.out.println(" Middle characters: "+ sb.append(str.substring((str.length() / 2) - 1, (str.length() / 2) + 1)));
		}
		 else
		 {
			 sb.append(str);
			 System.out.println(" Middle characters: "+ sb.charAt(str.length()/2));
		 }

	}

	static String findSpecialChar(String str) {
		StringBuilder sb = new StringBuilder();
		for (int iter = 0; iter < str.length(); iter++) {
			if (!Character.isAlphabetic(str.charAt(iter))) {
				sb.append(str.charAt(iter));

			}

		}
		return sb.toString();
	}
}
