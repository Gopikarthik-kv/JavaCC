package cc;

import java.util.Scanner;

public class DinnerTogether {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int samNum;
		int riyaNum;
		int iter = 1;
		int interval = 0;
		
		System.out.println("Enter the day interval of Sam: ");
		samNum = Integer.parseInt(in.nextLine());
		System.out.println("Enter the day interval of Riya: ");
		riyaNum = Integer.parseInt(in.nextLine());
		if (samNum <= 0 || riyaNum <= 0) {
			System.out.printf("%d to %d is not a valid interval", samNum, riyaNum);
			in.close();
			return;
		}
		in.close();
		do {
			if (iter % samNum == 0 && iter % riyaNum == 0) {
				interval = iter;
			}
			iter++;
		} while (interval == 0);
		
		System.out.println("Sam and Riya will have their dinner on day " + interval);
	}	
}
