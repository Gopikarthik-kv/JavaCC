package memberManipulation;

import java.util.ArrayList;
import java.util.List;

public class Library {

	private List<Member> memberList = new ArrayList<>();

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}

	public void addMember(Member memberObj) {
		this.memberList.add(memberObj);
	}

	public List<Member> viewAllMembers() {
		return memberList;
	}

	public List<Member> viewMembersByAddress(String address) {
		List<Member> memberListAddress = new ArrayList<>();
		for (Member mem : memberList) {
			if (mem.getAddress().equalsIgnoreCase(address))
				memberListAddress.add(mem);
		}

		return memberListAddress;
	}

	public Library() {

	}
}
