package processingPayments;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the number of payments:");
		int numberOfThreads = Integer.parseInt(reader.readLine());
		List<String> accounts = new ArrayList<>();
		int olbThreadCnt = 0;
		int ccThreadCnt = 0;
		int waThreadCnt = 0;
		System.out.println("Enter the payment details (Invoice ID, ACC Number, Payment Amount, Payment Type)");
		for (int iter = 0; iter < numberOfThreads; iter++) {
			accounts.add(reader.readLine());
			String[] arrAc = accounts.get(iter).split(",");
			if (arrAc[arrAc.length - 1].equalsIgnoreCase("OLB"))
				olbThreadCnt++;
			if (arrAc[arrAc.length - 1].equalsIgnoreCase("CC"))
				ccThreadCnt++;
			if (arrAc[arrAc.length - 1].equalsIgnoreCase("WA"))
				waThreadCnt++;
		}

		CreditCardPayment[] ccThread = new CreditCardPayment[ccThreadCnt];
		OnlineBankingPayment[] olBThread = new OnlineBankingPayment[olbThreadCnt];
		WalletPayment[] waThread = new WalletPayment[waThreadCnt];

		olbThreadCnt = 0;
		ccThreadCnt = 0;
		waThreadCnt = 0;
		for (String account : accounts) {
			String[] arrAc = account.split(",");

			if (arrAc[arrAc.length - 1].equalsIgnoreCase("CC")) {
				ccThread[ccThreadCnt] = new CreditCardPayment(Long.parseLong(arrAc[0]), arrAc[1],
						Double.parseDouble(arrAc[2]));
				ccThread[ccThreadCnt].run();
//				ccThread[ccThreadCnt].join();
				ccThreadCnt++;
			}

			
			if (arrAc[arrAc.length - 1].equalsIgnoreCase("OLB")) {
				olBThread[olbThreadCnt] = new OnlineBankingPayment(Long.parseLong(arrAc[0]), arrAc[1],
						Double.parseDouble(arrAc[2]));
				olBThread[olbThreadCnt].run();
				olbThreadCnt++;
			}

			if (arrAc[arrAc.length - 1].equalsIgnoreCase("WA")) {
				waThread[waThreadCnt] = new WalletPayment(Long.parseLong(arrAc[0]), arrAc[1],
						Double.parseDouble(arrAc[2]));
				waThread[waThreadCnt].run();
				waThreadCnt++;
			}
		}

	}

}
