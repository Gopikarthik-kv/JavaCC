package cc;

import java.util.Scanner;

public class Customer {

	public static void main(String[] args) {

		String name;
		int age;
		String gender;
		String fromLoc;
		Scanner in = new Scanner(System.in);

		System.out.println("Enter your name:");
		name = in.nextLine();

		System.out.println("Enter age:");
		age = Integer.parseInt(in.nextLine());

		System.out.println("Enter gender:");
		gender = in.nextLine();
		
		System.out.println("Hailing from:");
		fromLoc = in.nextLine();

		in.close();

		System.out.println("Welcome, " + name);
		System.out.println("Age:" + age);
		System.out.println("Gender:" + gender);
		System.out.println("City:" + fromLoc);

	}

}
