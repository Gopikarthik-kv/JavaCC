package inactiveUsers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

	public void makeInActive(int failedAttempts) {
		StringBuffer sb = new StringBuffer();
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE USER SET DELETED = 1 WHERE  FAILEDATTEMPTS > " + failedAttempts);
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<User> getInActiveUsers() {
		List<User> users = new ArrayList<>();
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"SELECT ID,Username,Address,Mobilenumber,Failedattempts FROM USER WHERE deleted = 1 ORDER BY Username DESC");
			while (rs.next()) {
				users.add(new User(Integer.parseInt(rs.getString("ID")), rs.getString("Username"), "Password",
						rs.getString("Address"), rs.getString("Mobilenumber"),
						Integer.parseInt(rs.getString("Failedattempts"))));
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;

	}

}
