package roleDetails;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		System.out.println("Role Details:");
		RoleDAO roleDAO = new RoleDAO();
		ArrayList<Role> roles = roleDAO.getAllRoles();
		for(Role role:roles) {
			System.out.println(role.getName());
		}

	}

}
