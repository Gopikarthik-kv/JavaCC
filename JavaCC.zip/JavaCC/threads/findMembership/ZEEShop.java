package findMembership;

import java.util.*;

public class ZEEShop extends Thread {

	private String memberCategory;

	private int count;

	private List<Member> memberList;

	public String getMemberCategory() {
		return memberCategory;
	}

	public void setMemberCategory(String memberCategory) {
		this.memberCategory = memberCategory;
	}

	public int getCount() {
		count = this.memberList.size();
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}

	public ZEEShop(String memberCategory, List<Member> memberList) {
		this.memberCategory = memberCategory;
		this.memberList = memberList;
	}

	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
