package cc;

import java.util.Scanner;

public class ReturnProduct {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		boolean eleFound = false;
		System.out.println("Array size");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 1) {
			System.out.println(arrSize + " is an invalid array size");
			in.close();
			return;
		}

		int[] arr1 = new int[arrSize];
		System.out.println("Array elements");
		int temp;
		int val = 1;
		String sinArr = "";
		for (temp = 0; temp < arrSize; temp++) {
			arr1[temp] = Integer.parseInt(in.nextLine());
			if (arr1[temp] < 1) {
				System.out.println(arrSize + " is an invalid array element");
				in.close();
				return;
			}
			sinArr = sinArr + arr1[temp] + ",";
		}
		sinArr = sinArr.substring(0, sinArr.length() - 1);

		in.close();

		for (temp = 0; temp < arrSize; temp++) {
			boolean notDivis = false;
			for (int tempDivis = 2; tempDivis < 10; tempDivis++) {
				if (tempDivis != arr1[temp] && arr1[temp] % tempDivis == 0) {
					notDivis = true;
					break;
				}
			}
			if (!notDivis) {
				eleFound = true;
				val = val * arr1[temp];
			}
		}

		if (!eleFound) {
			System.out.println("No element found in " + sinArr);
			return;
		}

		System.out.println(val);
	}

}
