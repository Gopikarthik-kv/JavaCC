package exceptionPkg;


public class Validator {
	
	public static boolean validateElevatorLoad(int elevatorLoad)throws MaximumLoadExceedException{
		boolean flag = false;
		
		if (elevatorLoad <= 1400){
			flag=true;
		}
		else{
	   		throw new MaximumLoadExceedException("Maximum load Exceeded");
		}
		return flag;
		
	}

}

