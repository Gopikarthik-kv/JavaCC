package processingPayments;

public class WalletPayment implements Runnable {
	private Long invoiceNumber;
	private String mobileNumber;
	private Double amount;

	public Long getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(Long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public WalletPayment(Long invoiceNumber, String mobileNumber, Double amount) {
		this.invoiceNumber = invoiceNumber;
		this.mobileNumber = mobileNumber;
		this.amount = amount;
	}

	public void run() {
		try {
			Thread.sleep(200);
			if (mobileNumber.contains("555"))
				System.out.println("Oops! Payment processing failed using the wallet mobile number " + this.getMobileNumber());
			else
				System.out.println("Payment processing completed using Wallet payment");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
