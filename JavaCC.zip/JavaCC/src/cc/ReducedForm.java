package cc;

import java.util.Arrays;
import java.util.Scanner;

public class ReducedForm {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the size of Array:");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 5 || arrSize > 10) {
			System.out.println(arrSize + " is an invalid array size");
			in.close();
			return;
		}

		int[] arr = new int[arrSize];
		String[] out = new String[arrSize];
		for (int temp = 0; temp < arrSize; temp++) {
			arr[temp] = Integer.parseInt(in.nextLine());
			out[temp] = String.valueOf(arr[temp]) + "," + temp;
		}
		in.close();

		Arrays.sort(arr);
		String outVal = "";
		for (int temp = 0; temp < arrSize; temp++) {
			for (int tempA = 0; tempA < arrSize; tempA++) {
				if (Integer.valueOf(out[tempA].split(",")[0]) == arr[temp]) {
					outVal = outVal + out[tempA].split(",")[1] + " ";
				}
			}
		}

		System.out.println(outVal.trim());

	}

}
