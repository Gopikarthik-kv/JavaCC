package averageAndGradeCalculation;

public class Advertisement {
	private int advertisementId;
	private String typeOfAd;

	public int getAdvertisementId() {
		return advertisementId;
	}

	public void setAdvertisementId(int advertisementId) {
		this.advertisementId = advertisementId;
	}

	public String getTypeOfAd() {
		return typeOfAd;
	}

	public void setTypeOfAd(String typeOfAd) {
		this.typeOfAd = typeOfAd;
	}

	public Advertisement(int advertisementId, String typeOfAd) {
		this.advertisementId = advertisementId;
		this.typeOfAd = typeOfAd;
	}
}
