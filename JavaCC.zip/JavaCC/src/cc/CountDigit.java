package cc;

import java.util.Scanner;

public class CountDigit {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int num;
		int number;
		int singleDigit;
		int count = 0;

		num = Integer.parseInt(in.nextLine());
		if (num < 1) {
			System.out.printf("%d falls behind the limit", num);
			in.close();
			return;
		}

		if ((int) (Math.log10(num) + 1) > 9) {
			System.out.printf("%d exceeds the limit", num);
			in.close();
			return;
		}

		singleDigit = Integer.parseInt(in.nextLine());

		if ((int) (Math.log10(singleDigit) + 1) > 1) {
			System.out.printf("%d is not valid", singleDigit);
			in.close();
			return;
		}

		in.close();
		number = num;
		while (num > 0) {
			count = (num % 10 == singleDigit) ? count + 1 : count;
			num = num / 10;
		}

		if (count == 0) 
			System.out.printf("%d is not available in %d",singleDigit, number );		
		else
			System.out.printf("Count of %d in %d is %d",singleDigit, number, count);

	}

}
