package dateStringBuilderBuffer;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Scanner;

public class TheNextRechargeDate {
//	public static void main(String[] args) {
//		Scanner in = new Scanner(System.in);
//		System.out.println("Recharged date");
//		String inDate = in.nextLine();
//		String pattern = "dd/MM/yyyy";
//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//
//		try {
//			Date date = new Date();
//			Date dateIn = simpleDateFormat.parse(inDate);
//			Calendar c = Calendar.getInstance();
//			c.setLenient(true);
//			c.setTime(dateIn);
//			if (dateIn.before(date) && inDate.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}")) {
//
//				System.out.println("Validity days");
//				int plusDate = Integer.parseInt(in.nextLine());
//				if (plusDate < 1) {
//					System.out.println(plusDate + " is not a valid days");
//					in.close();
//					return;
//				}
//
//				c.add(Calendar.DAY_OF_MONTH, plusDate);
//				System.out.println(simpleDateFormat.format(c.getTime()));
//
//			} else
//				System.out.println(inDate + " is not a valid date");
//
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			System.out.println(inDate + " is not a valid date");
//		}
//		in.close();
//	}
//
//	public static boolean isDateValid(int year, int month, int day) {
//		boolean dateIsValid = true;
//		try {
//			LocalDate.of(year, month, day);
//		} catch (DateTimeException e) {
//			dateIsValid = false;
//		}
//		return dateIsValid;
//	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Recharged date");
		String inDate = in.nextLine();
		DateTimeFormatter dateFormater = DateTimeFormatter.ofPattern("dd/MM/uuuu");

		try {
			LocalDate date = LocalDate.now();
			LocalDate dateIn = LocalDate.parse(inDate, dateFormater.withResolverStyle(ResolverStyle.STRICT));
			if ((dateIn.isBefore(date) || dateIn.equals(date))
					&& inDate.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}")) {
				System.out.println("Validity days");
				int plusDate = Integer.parseInt(in.nextLine());
				if (plusDate < 1) {
					System.out.println(plusDate + " is not a valid days");
					in.close();
					return;
				}

				System.out.println(dateIn.plusDays(plusDate).format(dateFormater));

			} else
				System.out.println(inDate + " is not a valid date");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(inDate + " is not a valid date");
		}
		in.close();
	}

	public static boolean isDateValid(int year, int month, int day) {
		boolean dateIsValid = true;
		try {
			LocalDate.of(year, month, day);
		} catch (DateTimeException e) {
			dateIsValid = false;
		}
		return dateIsValid;
	}

}
