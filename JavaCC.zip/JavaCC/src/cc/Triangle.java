package cc;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		int[] length = new int[3];

		Scanner in = new Scanner(System.in);
		for (int iter = 0; iter < 3; iter++) {
			length[iter] = Integer.parseInt(in.nextLine());
			if (length[iter] <= 0) {
				System.out.println(length[iter] + " is an Invalid Length");
				in.close();
				return;
			}
		}
		in.close();

		if (length[0] == length[1] && length[0] == length[2] && length[1] == length[2]) {
			System.out.printf("%d, %d, %d are the sides of Equilateral Triangle", length[0], length[1], length[2]);
		} else if ((length[0] == length[1] && length[0] != length[2])
				|| (length[1] == length[2] && length[1] != length[0])
				|| (length[2] == length[0] && length[2] != length[1])) {
			System.out.printf("%d, %d, %d are the sides of Isosceles Triangle", length[0], length[1], length[2]);
		}
		else {
			System.out.printf("%d, %d, %d are the sides of Scalene Triangle", length[0], length[1], length[2]);
		}

	}

}
