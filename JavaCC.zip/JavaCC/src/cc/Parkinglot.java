package cc;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Parkinglot {

	public static void main(String[] args) {
		Map<String, Integer> parkMap = new LinkedHashMap<>();
		int carCnt = 0;
		String floor = null;
		int temp = 0;
		Scanner in = new Scanner(System.in);

		for (int floorCnt = 1; floorCnt < 5; floorCnt++) {
			System.out.println("B" + floorCnt);
			temp = Integer.parseInt(in.nextLine());
			parkMap.put("B" + floorCnt, temp);
			if (temp <= 0) {
				System.out.println(temp + " is not a valid input");
				in.close();
				return;
			}
		}

		
		System.out.println("Car count");
		temp = Integer.parseInt(in.nextLine());
		in.close();

		for (Map.Entry<String, Integer> entry : parkMap.entrySet()) {
			floor = entry.getKey();
			carCnt = carCnt + entry.getValue();
			if (temp <= carCnt)
			{
				break;
			}
		}
		
		if(temp == carCnt + 1)
		{
			System.out.println("Parking slots in full");
			return;
		}
		
		System.out.println("The car can be parked at " + floor);

	}

}
