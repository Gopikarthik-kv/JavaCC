package memberManipulation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Library lib = new Library();
		List<Member> memberList = new ArrayList<>();
		lib.setMemberList(memberList);
		int choice;
		do {
			System.out.println("1.Add Member");
			System.out.println("2.View All Members");
			System.out.println("3.Search Member by address");
			System.out.println("4.Exit");
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Enter the id:");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the name:");
				String name = sc.nextLine();
				System.out.println("Enter the address:");
				String addr = sc.nextLine();

				Member mem = new Member(id, name, addr);
				lib.addMember(mem);

			}
				break;
			case 2: {

				if (memberList.size() < 1) {
					System.out.println("The list is empty");
					break;
				}

				for (Member m : lib.getMemberList()) {
					// display member id, member name and address
					System.out.println("Id:" + m.getMemberId());
					System.out.println("Name:" + m.getMemberName());
					System.out.println("Address:" + m.getAddress());
				}

			}
				break;
			case 3: {

				if (memberList.size() < 1) {
					System.out.println("The list is empty");
					break;
				}

				// fill in the code

				System.out.println("Enter the address:");

				String addres = sc.nextLine();
				// fill in the code

//                        System.out.println("None of the member is from "+...);

				// fill in the code

				// display member id, member name and address

				List<Member> membList = lib.viewMembersByAddress(addres);
				if (membList.size() < 1) {
					System.out.println("None of the member is from " + addres);
					break;
				}
				for (Member memb : membList) {
					System.out.println("Id:" + memb.getMemberId());
					System.out.println("Name:" + memb.getMemberName());
					System.out.println("Address:" + memb.getAddress());
				}
			}
				break;
			}
		} while (choice != 4);
		sc.close();
	}
}
