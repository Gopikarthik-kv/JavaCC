package averageRainfallcalculator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		RMCBO rain = new RMCBO();
		List<Integer> rainfallList = new ArrayList<>();
		rain.setRainfallList(rainfallList);
		int input = 0;
		do {
			System.out.println("1. Add rainfall details\n2. Average Rainfall occurred\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			switch (input) {
			case 1:
				System.out.println("Enter the Date");
				String inDate = sc.nextLine();
				if (!inDate.matches("[0-9]{2}[/]{1}[0-9]{2}[/]{1}[0-9]{4}")) {
					System.out.println("Invalid Date");
					break;
				}
				System.out.println("Enter the recorded rainfall in mm");
				int rainfall = Integer.parseInt(sc.nextLine());
				if (rainfall < 1) {
					System.out.println("Invalid Data");
					break;
				}
				rain.addRainfallDetails(rainfall);
				break;
			case 2:
				System.out.println("Average Rainfall recorded in mm");

				double cnt = rain.findAverageRainfallOccured();
				if (cnt == 0) {
					System.out.println("No records found");
				} else {
					System.out.println(cnt);
				}
				break;
			default:
				System.out.println("Thank you for using the Application");
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
