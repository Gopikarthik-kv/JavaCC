package calculatePassPercentage;

import java.util.List;

public class StudentBO {

	private List<Integer> studentList;

	public List<Integer> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Integer> studentList) {
		this.studentList = studentList;
	}

	// This method should add the marks secured by the students which passed as the
	// argument in to the List
	public void addStudentDetails(int securedMarks) {
		// Type your logic here
		this.studentList.add(securedMarks);
	}

	/*
	 * This method should return the pass percentage of the subject passPercentage
	 * can be calculated based on the following formula passPercentage= ((Total
	 * number of marks greater than 49) * 100) / (Total number of marks in the List)
	 * 
	 * For Example: if the list contains the following marks [50,48,75,81,42,95,62]
	 * passPercentage= (5*100) * 7 = 71
	 * 
	 */
	public int findPassPercentage() {
		int percentage = 0;
		// Type your logic here
		if(studentList.size()==0)
			percentage = -1;
		int passCnt = 0;
		for (int mark : studentList) {
			if (mark > 49) {
				passCnt++;
			}
		}
		if (passCnt > 0) {
			percentage = (passCnt * 100) / studentList.size();
		}
		return percentage;

	}
}
