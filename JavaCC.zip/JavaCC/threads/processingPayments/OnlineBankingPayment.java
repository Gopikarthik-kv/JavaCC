package processingPayments;

public class OnlineBankingPayment implements Runnable {
	private Long invoiceNumber;
	private String accountNumber;
	private Double amount;

	public Long getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(Long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public OnlineBankingPayment(Long invoiceNumber, String accountNumber, Double amount) {
		this.invoiceNumber = invoiceNumber;
		this.accountNumber = accountNumber;
		this.amount = amount;
	}

	public void run() {
		try {
			Thread.sleep(200);
			if (accountNumber.contains("555"))
				System.out
						.println("Oops! Payment processing failed using the online banking account number " + this.getAccountNumber());
			else
				System.out.println("Payment processing completed using Online banking");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
