package busyDayoftheweek;

import java.util.*;

public class UserInterface {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		LMCBO lmcbo = new LMCBO();
		List<String> appointmentDetailsList = new ArrayList<>();
		lmcbo.setAppointmentDetailsList(appointmentDetailsList);
		int input = 0;
		do {
			System.out.println("1. Add appointment details\n2. Day to find Count\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			String day;
			switch (input) {
			case 1:
				System.out.println("Enter the patient name");
				sc.nextLine();
				System.out.println("Enter the requesting appointment day");
				day = sc.nextLine();
				if (!day.matches("Monday|Tuesday|Wednesday|Thursday|Friday|Saturday")) {
					System.out.println("Not a valid day");
					break;
				}
				lmcbo.addAppointmentDayDetails(day);
				break;
			case 2:
				System.out.println("Enter the day to find the count");
				day = sc.nextLine();
				System.out.println(lmcbo.findAppointmentCount(day));
				break;
			default:
				System.out.println("Thank you for using the Application");
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
