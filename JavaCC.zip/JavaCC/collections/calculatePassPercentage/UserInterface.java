package calculatePassPercentage;

import java.util.*;

public class UserInterface {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		StudentBO studentBO = new StudentBO();
		List<Integer> studentList = new ArrayList<>();
		studentBO.setStudentList(studentList);
		int input = 0;
		do {
			System.out.println("1. Add student marks\n2. Find pass percentage\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			switch (input) {
			case 1:
				System.out.println("Enter the marks Secured");
				int mark = Integer.parseInt(sc.nextLine());

				if (mark < 1) {
					System.out.println("Not a valid mark");
					break;
				} else
					studentBO.addStudentDetails(mark);
				break;
			case 2:
				int passPerc = studentBO.findPassPercentage();
				if (passPerc < 1) {
					System.out.println("No Marks available");
					break;
				}
				System.out.println(passPerc);
				break;
			
			case 3:
				System.out.println("Thank you for using the Application");
				break;
			default:
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
