package cc;

import java.util.Scanner;

public class ArraySummation {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		boolean evenFound = false;
		System.out.println("Enter the array size");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 1 || arrSize > 10) {
			System.out.println(arrSize + " is an invalid array size");
			in.close();
			return;
		}

		int[] arr1 = new int[arrSize];
		System.out.println("Enter the elements in first array");
		int temp;
		for (temp = 0; temp < arrSize; temp++) {
			arr1[temp] = Integer.parseInt(in.nextLine());
		}

		int[] arr2 = new int[arrSize];
		System.out.println("Enter the elements in second array");
		for (temp = 0; temp < arrSize; temp++) {
			arr2[temp] = Integer.parseInt(in.nextLine());
			if ((arr1[temp] % 2 == 0 && arr2[temp] % 2 == 0) || arr1[temp] == 0 || arr2[temp] == 0) {
				evenFound = true;
				arr1[temp] = arr1[temp] + arr2[temp];
			} else
				arr1[temp] = 0;
		}

		in.close();
		if (!evenFound) {
			System.out.println("There are no even elements in the arrays");
			return;
		}
		for (temp = 0; temp < arrSize; temp++) {
			System.out.println(arr1[temp]);
		}

	}

}
