package setDesignationAndViewEmployeeInfo;

public class Employee {

	private int empId;
	private String empName;
	private int experience;
	private String designation;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation() {
		if (experience >= 5 && experience <= 7)
			this.designation = "Team Member";
		else if (experience >= 8 && experience <= 10)
			this.designation = "Team Lead";
		else if (experience >= 11 && experience <= 13)
			this.designation = "Project Manager";

	}
}
