package setGradeAndViewStudent;

public class Student {
	private int studId;
	private String studName;
	private int total;
	private char grade;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade() {
		
		if (total >= 900 && total <= 1000)
			this.grade = 'A';
		else if (total >= 800 && total <= 900)
			this.grade = 'B';
		else if (total >= 700 && total <= 3)
			this.grade = 'C';
	}

}
