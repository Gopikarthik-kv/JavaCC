package cc;

import java.util.Scanner;

public class UniqueProduct {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of items:");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 5 || arrSize > 20) {
			System.out.println(arrSize + " is an invalid item count");
			in.close();
			return;
		}

		System.out.printf("Enter the bar code ID for %d items:\n", arrSize);
		int[] arr = new int[arrSize];
		String val = "";
		boolean found = false;
		int availCount = 0;
		String out = "";
		for (int temp = 0; temp < arrSize; temp++) {
			arr[temp] = Integer.parseInt(in.nextLine());
			if ((int) (Math.log10(arr[temp]) + 1) != 3) {
				System.out.println(arr[temp] + "  is an invalid bar code ID");
				in.close();
				return;
			}
			out = out + +arr[temp] + ",";

			if (!String.valueOf(arr[temp] / 10).contains(String.valueOf(arr[temp] % 10))
					&& !String.valueOf(arr[temp]).substring(1, 3).contains(String.valueOf(arr[temp]).substring(0, 1))) {
				found = true;
				availCount++;
				val = val + arr[temp] + "\n";
			}
		}
		in.close();

		if (!found)
			System.out.println("There are no items with Unique number in " + out.substring(0, out.length() - 1));
		else
			System.out.println(val + "There are " + availCount + " items with Unique number in the bar code ID");
	}
}
