package cc;

	import java.util.Arrays;
	import java.util.Scanner;
	
	public class SubtractTheMax {
	
		public static void main(String[] args) {
	
			Scanner in = new Scanner(System.in);
			System.out.println("Enter the size of an array:");
			int arrSize = Integer.parseInt(in.nextLine());
	
			if (arrSize < 5 || arrSize > 10) {
				System.out.println(arrSize + " is an invalid array size");
				in.close();
				return;
			}
			
			int[] arr = new int[arrSize];
			System.out.println("Enter array elements:");
			for (int temp = 0; temp < arrSize; temp++) {
				arr[temp] = Integer.parseInt(in.nextLine());
			}
			in.close();
			
	        int max = Arrays.stream(arr).max().getAsInt();
	        for (int temp = 0; temp < arrSize; temp++) {
				System.out.println(max - arr[temp]);
			}
	        
	
		}
	}
