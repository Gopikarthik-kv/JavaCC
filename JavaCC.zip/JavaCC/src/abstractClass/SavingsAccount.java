package abstractClass;

public class SavingsAccount extends Mobile {

	private double minimumBalance;

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public SavingsAccount(int accNumber, String holderName, double balance, double minimumBalance) {
//		super(accNumber, holderName, balance);
		this.minimumBalance = minimumBalance;
	}

	public SavingsAccount() {

	}

//	@Override
//	public double calculateInterest() {
//		// TODO Auto-generated method stub
//		return (double) this.balance * 0.05;
//	}

}
