package gpaCalc;

import java.util.*;

public class UserInterface {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		GradeBO gradeBO = new GradeBO();
		List<Integer> gradeList = new ArrayList<>();
		gradeBO.setGradeList(gradeList);

		int input = 0;
		do {
			System.out.println("1. Add GradePoint\n2. Calculate GPA\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			switch (input) {
			case 1:
				System.out.println("Enter the gradePoint scored");
				int mark = Integer.parseInt(sc.nextLine());

				if (mark < 1) {
					System.out.println("Not a valid mark");
					break;
				} else
					gradeBO.addGradeDetails(mark);
				break;
			case 2:
				double passPerc = gradeBO.getGPAScored();
				if (passPerc < 1) {
					System.out.println("No GradePoints available");
					break;
				}
				System.out.println("GPA Scored\n" + passPerc);
				break;

			case 3:
				System.out.println("Thank you for using the Application");
				break;
			default:
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
