package cc;

import java.util.Scanner;

public class ProductEqualSum {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the array size");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 1 && arrSize > 10) {
			System.out.println(arrSize + " is invalid array size");
			in.close();
			return;
		}

		int[] arr1 = new int[arrSize];
		int[] arrVal1 = new int[arrSize];
		int temp;
		String val1 = "";
		System.out.println("Enter the elements of the first array");
		for (temp = 0; temp < arrSize; temp++) {
			arr1[temp] = Integer.parseInt(in.nextLine());
			if (arr1[temp] < 10 && arr1[temp] > 999) {
				System.out.println(arr1[temp] + " is not a valid input");
				in.close();
				return;
			}
			arrVal1[temp] = getProduct(arr1[temp]);
			val1 = val1 + arr1[temp]+ " ";
		}
		val1 = val1.substring(0, val1.length() - 1);

		int[] arr2 = new int[arrSize];
		int[] arrVal2 = new int[arrSize];
		String val2 = "";
		System.out.println("Enter the elements of the second array");
		for (temp = 0; temp < arrSize; temp++) {
			arr2[temp] = Integer.parseInt(in.nextLine());
			if (arr2[temp] < 10 && arr2[temp] > 999) {
				System.out.println(arr2[temp] + " is not a valid input");
				in.close();
				return;
			}
			arrVal2[temp] = getSum(arr2[temp]);
			val2 = val2 + arr2[temp] + " ";
		}
		val2 = val2.substring(0, val2.length() - 1);

		in.close();
		boolean notFound = false;
		for (temp = 0; temp < arrSize; temp++) {
			if (arrVal1[temp] == arrVal2[temp]) {
				notFound = true;
				System.out.println(arr1[temp] + "," + arr2[temp]);
			}
		}

		if (!notFound)
			System.out.println("No pair found in " + val1 + " and " + val2);

	}

	/* Function to get product of digits */
	static int getProduct(int n) {
		int product = 1;

		while (n != 0) {
			product = product * (n % 10);
			n = n / 10;
		}

		return product;
	}

	static int getSum(int n) {
		int sum = 0;

		while (n != 0) {
			sum = sum + n % 10;
			n = n / 10;
		}

		return sum;
	}

}
