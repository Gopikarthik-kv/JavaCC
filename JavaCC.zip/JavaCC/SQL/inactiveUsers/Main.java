package inactiveUsers;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Enter the number of login attempts");
		Scanner in = new Scanner(System.in);
		int failedAttempts = Integer.parseInt(in.nextLine());
		in.close();
		UserDAO ud = new UserDAO();
		ud.makeInActive(failedAttempts);
		System.out.println("Inactive user Details : \nName Address Mobile Number");
		List<User> users = ud.getInActiveUsers();
		for (User user : users) {
			System.out.println(user.getUsername() + " " + user.getAddress() + " " + user.getMobileNumber());
		}
	}

}
