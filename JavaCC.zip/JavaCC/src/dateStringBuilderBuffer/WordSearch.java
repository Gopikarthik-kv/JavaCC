package dateStringBuilderBuffer;

import java.util.Scanner;

public class WordSearch {
	public static void main(String[] args) {
		System.out.println("Enter the string:");
		Scanner in = new Scanner(System.in);
		String fStr = in.nextLine().toLowerCase();

		if (!fStr.matches("[A-Za-z ]+")) {
			System.out.println("String should not contain " + findSpecialChar(fStr).trim());
			in.close();
			return;
		}

		System.out.println("Enter the string to be searched:");
		String sStr = in.nextLine();

		if (!sStr.matches("[A-Za-z ]+")) {
			System.out.println("String should not contain " + findSpecialChar(sStr).trim());
			in.close();
			return;
		}

		in.close();
		if (!fStr.toLowerCase().contains(sStr.toLowerCase())) {
			System.out.println(sStr + " not found");
			return;
		}

		if (fStr.substring(fStr.indexOf(sStr) + 1, fStr.length()).indexOf(sStr) > 0) {
			System.out.println(sStr + " is found more than once");
			return;
		}

		System.out.println((2 * fStr.indexOf(sStr)) + sStr.length() - 1);

		in.close();
	}

	static String findSpecialChar(String str) {
		StringBuilder sb = new StringBuilder();
		for (int iter = 0; iter < str.length(); iter++) {
			if (!Character.isAlphabetic(str.charAt(iter))) {
				sb.append(str.charAt(iter));
				
			}

		}
		return sb.toString();
	}
}
