package abstractClassCC;
import java.io.BufferedReader;
import java.io.IOException;

public class ScrumMaster extends User {

	public void createRequirements(String detail, Requirement[] requirement) {
		for (Requirement req : requirement) {
			if (req.getId() == null) {
				req.setId(Integer.parseInt(detail.split(",")[0]));
				req.setDescription(detail.split(",")[1]);
				break;
			}
		}
	}

	public int countTotalRequirements(Requirement[] requirement) {
		return requirement.length;

	}

	Boolean assignreqmts(BufferedReader br, Requirement[] requirement, User user[]) throws IOException {

		if (requirement.length == 0)
			return false;
		
		for (Requirement req : requirement) {
			System.out.println(req.getId() + ". " + req.getDescription());
		}
		System.out.println("Enter the requirement id and user name :");
		String input = br.readLine().trim();
		// Validate Requirements
		boolean reqFound = false;
		Requirement reqAss = null;
		User reqAssUser = null;
		for (Requirement req : requirement) {
			if (req.getId().toString().equalsIgnoreCase(input.split(",")[0])) {
				reqFound = true;
				reqAss = req;
				break;
			}
		}
		boolean usrFound = false;
		for (User usr : user) {
			if (usr.getUserName().equalsIgnoreCase(input.split(",")[1])) {
				reqAssUser = usr;
				usrFound = true;
				break;
			}
		}
		if (usrFound && reqFound) {
			reqAss.setAssignedTo(reqAssUser);
			return true;
		} else
			return false;

	}

	public ScrumMaster() {
	}

	public ScrumMaster(String userName, String password, String name, String role) {
		super(userName, password, name, role);
		// TODO Auto-generated constructor stub
	}

}

