package abstractClass;

public abstract class Shape {
	public abstract double calculateVolume();
}
