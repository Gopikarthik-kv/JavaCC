package abstractClassCC;


import java.io.BufferedReader;
import java.io.IOException;

public class User {
	private String userName;
	private String password;
	private String name;
	private String role;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public User(String userName, String password, String name, String role) {
		this.userName = userName;
		this.password = password;
		this.name = name;
		this.role = role;
	}

	public User() {
	}

	void display(BufferedReader br, Requirement[] requirement, User[] user) throws IOException {
		int input = 1;
		if (this.getRole().equalsIgnoreCase("SM")) {
			do {
				System.out.println(
						"1. Create BackLog\n2. Count Requirements\n3. Assign Requirements\n4. Logout\nEnter your choice :");
				input = Integer.parseInt(br.readLine().trim());
				ScrumMaster sm = new ScrumMaster();

				switch (input) {
				case 1:
					System.out.println("Enter the number of requirement to create :");
					int numOfReq = Integer.parseInt(br.readLine().trim());
					requirement = new Requirement[numOfReq];
					for (int reqCnt = 0; reqCnt < numOfReq; reqCnt++) {
						System.out.printf("Enter the id and description %d:\n", reqCnt + 1);
						String detail = br.readLine().trim();
						requirement[reqCnt] = new Requirement();
						sm.createRequirements(detail, requirement);
					}
					System.out.println("Requirement created successfully");
					break;
				case 2:
					System.out.println("The total number of requirement is :" + sm.countTotalRequirements(requirement));
					break;
				case 3:
					if (sm.assignreqmts(br, requirement, user))
						System.out.println("Assigned successfully");
					else
						System.out.println("Assign failed");
				}
			} while (input != 4);
		} else if (this.getRole().equalsIgnoreCase("TM")) {
			do {
				System.out.println("1. Display requirement list\n2. Logout Enter your choice :");
				input = Integer.parseInt(br.readLine().trim());
				TeamMember tm = new TeamMember();
				if (input == 1)
					tm.myRequriements(requirement, this.getUserName());
				else
					return;

			} while (input != 2);

		} else {
			do {
				System.out.println(
						"1. List reqiurements\n2. Allocate budget\n3. Allocate plan time\n4. Logout\nEnter your choice :");
				input = Integer.parseInt(br.readLine().trim());
				ProductOwner po = new ProductOwner();
				switch (input) {
				case 1:
					if (requirement.length == 0) {
						System.out.println("No records found");
						break;
					}
					System.out.format("%s %s %s %s\n", "Id", "Description", "Budget", "Time");
					for (Requirement req : requirement) {
						System.out.format("%s %s %.2f %s\n", req.getId(), req.getDescription(),
								req.getBudget(), req.getPlanTime());
					}

					break;
				case 2:
					System.out.println("Enter the id and budget :");
					String budgetDetail = br.readLine().trim();
					if (po.allocateBudget(budgetDetail, requirement))
						System.out.println("Budget assigned successfully");
					else
						System.out.println("Budget assign failed");
					break;
				case 3:
					System.out.println("Enter the id and plan time :");
					String planDetail = br.readLine().trim();
					if (po.allocatePlanTime(planDetail, requirement))
						System.out.println("Time assigned successfully");
					else
						System.out.println("No record found");
					break;
				}

			} while (input != 4);

		}

		Main.req = requirement;
	}
}
