package studentGradeCount;

import java.util.*;

public class UserInterface {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		StudentBO pb = new StudentBO();
		Map<String, Character> studentMap = new HashMap<>();
		pb.setStudentMap(studentMap);
		int input = 0;
		do {
			System.out.println("1. Add student details\n2. Find count of students\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			char grade;
			switch (input) {
			case 1:
				System.out.println("Enter the student roll number");
				String rollNum = sc.nextLine();
				System.out.println("Enter the grade Secured");
				grade = sc.nextLine().charAt(0);
				pb.addStudentDetails(rollNum, grade);
				break;
			case 2:
				System.out.println("Enter the grade to find the count of students");
				grade = sc.nextLine().charAt(0);
				int cnt = pb.findCountofStudents(grade);
				if (cnt == 0) {
					System.out.println("No students found");
				} else {
					System.out.println(cnt);
				}
				break;
			default:
				System.out.println("Thank you for using the Application");
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
