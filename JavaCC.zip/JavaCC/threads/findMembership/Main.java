package findMembership;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number of Members:");
		int threadCount = Integer.parseInt(input.nextLine());
		List<Member> members = new ArrayList<>();
		for (int iter = 0; iter < threadCount; iter++) {
			System.out.println("Enter the Member Details:");
			String[] temp = input.nextLine().split(":");
			members.add(new Member(temp[0], temp[1], temp[2]));
		}

		System.out.println("Enter the number of times Membership category needs to be searched:");
		threadCount = Integer.parseInt(input.nextLine());
		ZEEShop[] threads = new ZEEShop[threadCount];
		for (int iter = 0; iter < threadCount; iter++) {
			System.out.println("Enter the String:");
			String category = input.nextLine();
			List<Member> membersCate = new ArrayList<>();
			for (Member mem : members) {
				if (mem.getCategory().equalsIgnoreCase(category))
					membersCate.add(mem);
			}
			threads[iter] = new ZEEShop(category, membersCate);
			threads[iter].start();
		}

		for (int x = 0; x < threadCount; x++) {
			System.out.println(threads[x].getMemberCategory() + ":" + threads[x].getCount());
		}

		input.close();

	}

}
