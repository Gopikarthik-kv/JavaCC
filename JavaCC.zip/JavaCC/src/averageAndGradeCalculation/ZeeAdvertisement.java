package averageAndGradeCalculation;

import java.util.Scanner;

public class ZeeAdvertisement {

	public static void main(String[] args) {
		Advertisement[] ad = createAd();
		System.out.println("No of advertisement published " + ad.length);
		for (int temp = 0; temp < ad.length; temp++) {
			System.out.println("Advertisement " + temp + 1);
			System.out.println("Id:" + ad[temp].getAdvertisementId());
			System.out.println("Type:" + ad[temp].getTypeOfAd());
		}
	}

	public static Advertisement[] createAd() {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number Ads to created");
		int adLength = Integer.parseInt(in.nextLine());
		Advertisement[] ad = new Advertisement[adLength];
		for (int temp = 0; temp < adLength; temp++) {
			System.out.println("Enter advertisement id:");
			int advertisementId = Integer.parseInt(in.nextLine());
			System.out.println("Enter advertisement type:");
			String typeOfAd = in.nextLine();
			ad[temp] = new Advertisement(advertisementId, typeOfAd);
		}
		in.close();
		return ad;
	}

}
