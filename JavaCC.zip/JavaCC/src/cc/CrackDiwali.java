package cc;

import java.util.Scanner;

public class CrackDiwali {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number from the slot");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 5 || arrSize > 15) {
			System.out.println(arrSize + " is not a valid slot number");
			in.close();
			return;
		}

		System.out.printf("Enter the %d customer names\n", arrSize);

		String[] arr = new String[arrSize];
		for (int temp = 0; temp < arrSize; temp++) {
			arr[temp] = in.nextLine();
		}

		System.out.println("Enter the alphabet from the slot");
		String alp = in.nextLine();
		in.close();

		String out = "";
		for (int temp = 0; temp < arrSize; temp++) {
			if (arr[temp].contains(alp.toLowerCase()) || arr[temp].contains(alp.toUpperCase()))
				out = out + arr[temp] + "\n";
		}

		if (out == "") {
			System.out.println("Letter " + alp + " is not present in any of the customer's name");
			return;
		} else {
			System.out.println("Customers List\n" + out.trim());
		}

	}

}
