package searchbyFirstName;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
	public void createUser(User user) {
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
//			ResultSet rs = stmt.executeQuery("SELECT MAX(ID) +1 AS ID FROM CONTACT");
//
//			int conid = Integer.parseInt(rs.getString("ID"));
			System.out.println("insert into contact (Id, mobilenumber, emailid) values (" + user.getContact().getId()
					+ ", '" + user.getContact().getMobileNumber() + "','" + user.getContact().getEmailId() + "'");
			stmt.executeUpdate("insert into contact (Id, mobilenumber, emailid) values (" + user.getContact().getId()
					+ ", '" + user.getContact().getMobileNumber() + "','" + user.getContact().getEmailId() + "'");
			con.commit();
//			rs = stmt.executeQuery("SELECT MAX(ID) +1 AS ID FROM USER");
//			int id = Integer.parseInt(rs.getString("ID"));
			stmt.executeUpdate("insert into user (Id,username,firstname,lastname,password,contact_id) values ("
					+ user.getId() + ", '" + user.getUserName() + "','" + user.getFirstName() + "','"
					+ user.getLastName() + "','" + user.getPassword() + "'," + user.getContact().getId());
			con.commit();
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<User> findByFirstName(String firstName) {
		List<User> users = new ArrayList<>();
		Contact contact;
		try {
			DbConnection db = new DbConnection();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("\r\n"
					+ "SELECT User.Id As UserID,username,firstname,lastname,password, mobilenumber,emailid, contact.id As conID,mobilenumber,emailid FROM user LEFT JOIN contact ON user.id = contact.id AND user.firstname LIKE '%"
					+ firstName + "%'");
			while (rs.next()) {
				contact = new Contact(Integer.valueOf(rs.getString("conID")), rs.getString("mobilenumber"),
						rs.getString("emailid"));
				users.add(new User(Integer.valueOf(rs.getString("UserID")), rs.getString("username"),
						rs.getString("firstname"), rs.getString("lastname"), rs.getString("password"), contact));
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException | IllegalAccessException | InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}
}
