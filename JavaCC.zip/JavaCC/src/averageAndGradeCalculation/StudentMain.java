package averageAndGradeCalculation;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		Student student = getStudentDetails();
		student.calculateAvg();
		student.findGrade();
		System.out.println("Id:" + student.getId());
		System.out.println("Name:" + student.getName());
		System.out.printf("Average:%.2f\n", student.getAverage());
		System.out.println("Grade:" + student.getGrade());
	}

	public static Student getStudentDetails() {
		Student student;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the id:");
		int id = Integer.parseInt(in.nextLine());
		System.out.println("Enter the name:");
		String name = in.nextLine();
		int numOfSub = 0;
		do {
			System.out.println("Enter the no of subjects:");
			numOfSub = Integer.parseInt(in.nextLine());
			if (numOfSub < 1)
				System.out.println("Invalid number of subject");
		} while (numOfSub < 1);

		int[] marks = new int[numOfSub];
		for (int temp = 0; temp < numOfSub; temp++) {
			do {
				System.out.printf("Enter mark for subject %d: \n", temp + 1);
				marks[temp] = Integer.parseInt(in.nextLine());
				if (marks[temp] < 1 && marks[temp] > 100)
					System.out.println("Invalid Mark");
			} while (marks[temp] < 1 && marks[temp] > 100);
		}
		in.close();
		student = new Student(id, name, marks);
		return student;
	}
}
