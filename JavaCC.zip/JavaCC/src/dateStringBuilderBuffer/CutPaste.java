package dateStringBuilderBuffer;

import java.util.Scanner;

public class CutPaste {

	public static void main(String[] args) {
		System.out.println("Enter the String:");
		Scanner in = new Scanner(System.in);
		StringBuilder sb = new StringBuilder();
		sb.append(in.nextLine());
		System.out.println("Position:");
		int pos = Integer.parseInt(in.nextLine());
		in.close();
		if (pos > sb.length()) {
			System.out.println("Position exceeds the string " + sb);
			return;
		}
		if (pos < 1) {
			System.out.println("String cannot contain Position " + pos);
			return;
		}
		System.out.println(sb.deleteCharAt(pos-1));
	}

}
