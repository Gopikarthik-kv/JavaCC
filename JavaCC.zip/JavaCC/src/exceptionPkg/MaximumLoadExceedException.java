package exceptionPkg;

public class MaximumLoadExceedException extends Exception {

	private static final long serialVersionUID = 1L;

	public MaximumLoadExceedException(String s) {
		super(s);
	}
}
