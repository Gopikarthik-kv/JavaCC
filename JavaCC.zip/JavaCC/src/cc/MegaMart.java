package cc;

import java.util.*;

public class MegaMart {

	public static void main(String[] args) {
		int custID;
		float billAmnt;

		Scanner in = new Scanner(System.in);

		System.out.println("Enter the Customer Id");
		custID = Integer.parseInt(in.nextLine());

		if (custID <= 0) {
			System.out.printf("%s is not a valid Customer Id", String.valueOf(custID));
			in.close();
			return;
		}

		System.out.println("Enter the Bill amount");
		billAmnt = Float.parseFloat(in.nextLine());		
		in.close();

		if (billAmnt <= 0) {
			System.out.printf("%.0f is not a valid Bill Amount", billAmnt);
			return;
		}else if (billAmnt >= 1000) {
			if (custID <= 100) {
				billAmnt = (float) (billAmnt - (billAmnt * .15));
			} else if (custID > 100 && custID <= 250) {
				billAmnt = (float) (billAmnt - (billAmnt * .18));
			} else if (custID > 250 && custID <= 500) {
				billAmnt = (float) (billAmnt - (billAmnt * .23));
			} else if (custID > 500 && custID <= 1000) {
				billAmnt = (float) (billAmnt - (billAmnt * .28));
			} else {
				billAmnt = (float) (billAmnt - (billAmnt * .32));
			}
		}

		System.out.printf("Total Price is %.2f", billAmnt);
	}
}
