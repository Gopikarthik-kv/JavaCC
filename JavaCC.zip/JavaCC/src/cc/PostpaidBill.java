package cc;

import java.util.Scanner;

public class PostpaidBill {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numCalls;
		int numSMS;
		float billAmnt;
		System.out.println("Enter the number of calls:");
		numCalls = Integer.parseInt(in.nextLine());
		if (numCalls < 0) {
			System.out.printf("%d is an invalid input", numCalls);
			in.close();
			return;
		}

		if (numCalls > 1000) {
			System.out.printf("%d exceeds the maximum limit", numCalls);
			in.close();
			return;
		}

		System.out.println("Enter the number of SMS:");
		numSMS = Integer.parseInt(in.nextLine());
		if (numSMS < 0) {
			System.out.printf("%d is an invalid input", numSMS);
			in.close();
			return;
		}

		if (numSMS > 1000) {
			System.out.printf("%d exceeds the maximum limit", Math.max(numSMS, numCalls));
			in.close();
			return;
		}

		in.close();

		if (numCalls >= 100)
			numCalls = numCalls - 100;

		if (numSMS >= 100)
			numSMS = numSMS - 100;

		billAmnt = (float) (((numCalls) * 1.5) + ((numSMS) * 0.5)) + 150;
		System.out.printf("Amount to be paid is Rs.%.2f", (billAmnt + (billAmnt * 0.055)));
	}

}
