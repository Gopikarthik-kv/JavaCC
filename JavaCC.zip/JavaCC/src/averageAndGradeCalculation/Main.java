package averageAndGradeCalculation;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.println("Enter the no.of passengers:");
		int numOfPassenger = Integer.parseInt(in.nextLine());
		Passenger[] pass = new Passenger[numOfPassenger];
		for (int temp = 0; temp < numOfPassenger; temp++) {
			System.out.println("Passenger " + (temp + 1));
			System.out.println("Enter the ticketid:");
			int ticketId = Integer.parseInt(in.nextLine());
			System.out.println("Enter the name:");
			String name = in.nextLine();
			System.out.println("Enter the gender:");
			String gender = in.nextLine();
			System.out.println("Enter the address:");
			String address = in.nextLine();
			pass[temp] = new Passenger(ticketId, name, gender, address);
		}
		in.close();

//		for (int temp = 0; temp < numOfPassenger; temp++) {
////			System.out.println("ticketid:" + pass[temp].getTicketid() + ",name:" + pass[temp].getName() + ",gender:"
////					+ pass[temp].getGender() + ",address:" + pass[temp].getAddress());
//			pass[temp].displayPassengerDetails();
//		}
	}
}
