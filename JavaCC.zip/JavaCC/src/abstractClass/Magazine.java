package abstractClass;

//Make the necessary changes to make this class inherit the Book class
public class Magazine extends Book {

	private String magazineType;

	// Constructor
	public Magazine(int ISBNNumber, String bookName, double price, String magazineType) {
		super(ISBNNumber, bookName, price);
		this.magazineType = magazineType;
	}

	public Magazine() {

	}

	// Getters and Setters

	public String getMagazineType() {
		return magazineType;
	}

	public void setMagazineType(String magazineType) {
		this.magazineType = magazineType;
	}

	@Override
	public double calculateDiscount() {
		return (double) this.price * 0.15;
	}

	// Override the calculateDiscount() method to return 15% of price

	// public double calculateDiscount() {

	// }

}
