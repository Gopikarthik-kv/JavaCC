package exceptionPkg;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the RAM capacity (in GB)");
		int rCapacity = sc.nextInt();
		System.out.println("Enter the HD capacity available (in GB)");
		int hdCapacity = sc.nextInt();
		System.out.println("Enter the Net Connection speed (in KBPS)");
		int speed = sc.nextInt();
		sc.close();
//		try {
//			if (Validator.validateElevatorLoad(rCapacity, hdCapacity, speed))
//				System.out.println("Ready to Go");
//		} catch (MaximumLoadExceedException ex) {
//			System.out.println(ex.getMessage());
//		}

	}

}
