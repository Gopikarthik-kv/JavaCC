package setDesignationAndViewEmployeeInfo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Company {
	public Employee viewEmployee(int eid) {

		Employee emp = new Employee();
		try {
			DB db = new DB();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT empId, empName, experience FROM employee WHERE empId = " + eid);

			emp.setEmpId(Integer.parseInt(rs.getString("empId")));
			emp.setEmpName(rs.getString("empName"));
			emp.setExperience(Integer.parseInt(rs.getString("experience")));
			emp.setDesignation();
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}
}
