package ticketPriceCalculation;

import java.util.Scanner;

public class Main {
	private static Scanner in;

	public static void main(String[] args) {
		in = new Scanner(System.in);
		Ticket ticket = new Ticket();
		System.out.println("Enter no of bookings:");
		int numBook = Integer.parseInt(in.nextLine());
		do {
			System.out.println("Enter the available tickets:");
			Ticket.setAvailableTickets(Integer.parseInt(in.nextLine()));
		} while (Ticket.getAvailableTickets() < 1);
		for (int temp = 0; temp < numBook; temp++) {
			System.out.println("Enter the ticketid:");
			ticket.setTicketid(Integer.parseInt(in.nextLine()));
			System.out.println("Enter the price:");
			ticket.setPrice(Integer.parseInt(in.nextLine()));
			System.out.println("Enter the no of tickets:");
			int numOfTickets = Integer.parseInt(in.nextLine());
			System.out.println("Available tickets:" + Ticket.getAvailableTickets());
			int amount = ticket.calculateTicketCost(numOfTickets);
			System.out.println("\nTotal amount: " + amount);
			System.out.println("\nAvailable ticket after booking:" + Ticket.getAvailableTickets());

		}
	}

}
