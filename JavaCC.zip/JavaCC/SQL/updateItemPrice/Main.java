package updateItemPrice;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("Item details :");
		ItemDAO itemDAO = new ItemDAO();
		Scanner in = new Scanner(System.in);
		List<Item> items = itemDAO.getAllItems();
		listItems(items);
		System.out.println("Enter the item id to update :");
		String item = in.nextLine();
		System.out.println("Enter the new price :");
		Double price = Double.parseDouble(in.nextLine());
		in.close();
		itemDAO.updateItemPrice(item, price);
		items = itemDAO.getAllItems();
		listItems(items);
	}

	static void listItems(List<Item> items) {
		
		System.out.println("Item ID Item Name Price");
		for (Item item : items) {
			System.out.println(item.getId() + " " + item.getName() + " " + item.getPrice());
		}
	}
}
