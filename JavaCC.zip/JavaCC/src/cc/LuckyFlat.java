package cc;

import java.util.Scanner;

public class LuckyFlat {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of flats available:");
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 5 || arrSize > 15) {
			System.out.println(arrSize + " is an invalid availability");
			in.close();
			return;
		}

		System.out.println("Enter the flat numbers:");
		int[] arr = new int[arrSize];
		String out = "";
		String validOut = "";
		boolean available = false;
		for (int temp = 0; temp < arrSize; temp++) {
			arr[temp] = Integer.parseInt(in.nextLine());
			if ((int) (Math.log10(arr[temp]) + 1) != 3) {
				System	.out.println(arr[temp] + "  is an invalid flat number");
				in.close();
				return;
			}
			if (firstDigit(arr[temp]) == 8) {
				System.out.println(arr[temp] + " will not be considered");
				in.close();
				return;
			}
			out = out + arr[temp] + ",";
			if (getSum(arr[temp]) == 5) {
				available = true;
				validOut = validOut + arr[temp] + "\n";
			}
		}
		in.close();

		if (!available) {
			System.out.println("There is no lucky flat in " + out.substring(0, out.length() - 1));
		} else {
			System.out.println(validOut.trim());
		}

	}

	static int getSum(int n) {
		int sum = 0;
		
		while (n != 0) {
			sum = sum + n % 10;
			n = n / 10;
		}
		if (sum > 9)
			return getSum(sum);
		else
			return sum;
	}

	static int firstDigit(int x) {
		while (x > 9) {
			x /= 10;
		}
		return x;
	}

}
