package abstractClass;

public class Item {
	private String itemName;
	private float itemCost;
	private float totalCost;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public float getItemCost() {
		return itemCost;
	}

	public void setItemCost(float itemCost) {
		this.itemCost = itemCost;
	}

	public float getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(float totalCost) {
		this.totalCost = totalCost;
	}

	public Item(String itemName, float itemCost) {
		this.itemName = itemName;
		this.itemCost = itemCost;
	}
	public Item() {
		
	}
}
