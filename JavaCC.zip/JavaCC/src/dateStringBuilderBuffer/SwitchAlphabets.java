package dateStringBuilderBuffer;

import java.util.Scanner;

public class SwitchAlphabets {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();
		String vowel = "aeiouAEIOU";
		in.close();

		StringBuffer sb = new StringBuffer();
		for (int iter = 0; iter < str.length(); iter++) {
			if (vowel.indexOf(str.charAt(iter)) > -1)
				sb.append("#");
			else
				sb.append(str.charAt(iter));
		}

		if (sb.indexOf("#") < 0) {
			System.out.println(str + " has no vowels");
			return;
		}
		System.out.println(sb.toString());
	}
}
