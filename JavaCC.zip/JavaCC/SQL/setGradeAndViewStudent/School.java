package setGradeAndViewStudent;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class School {
	public Student viewStudent(int sid) {
		Student stu = new Student();
		try {
			DB db = new DB();
			Connection con = db.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT studId, studName, total FROM employee WHERE empId = " + sid);
			if (rs.next()) {
				stu.setStudId(Integer.parseInt(rs.getString("studId")));
				stu.setStudName(rs.getString("studName"));
				stu.setTotal(Integer.parseInt(rs.getString("total")));
				stu.setGrade();
			}
			rs.close();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stu;
	}
}
