package setCategoryAndViewProductDetails;

public class Product {
	private int prodId;
	private String prodName;
	private double unitPrice;
	private char category;

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public char getCategory() {
		return category;
	}

	public void setProductCategory() {
		if (unitPrice >= 100 && unitPrice <= 999)
			this.category = 'C';
		else if (unitPrice >= 1000 && unitPrice <= 9999)
			this.category = 'B';
		else if (unitPrice >= 10000 && unitPrice <= 99999)
			this.category = 'A';
		// fill the required logic

	}
	

}
