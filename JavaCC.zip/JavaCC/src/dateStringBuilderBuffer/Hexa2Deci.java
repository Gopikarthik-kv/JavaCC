package dateStringBuilderBuffer;

import java.util.HashMap;
import java.util.Scanner;

public class Hexa2Deci {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String hexadecimal = in.nextLine();
		in.close();
		if (hexadecimal.length() < 4 && hexadecimal.length() > 5) {
			System.out.println(hexadecimal + " is a " + hexadecimal.length() + " Invalid");
			return;
		}

		if (hexadecimal.matches(".*[G-Z].*")) {
			System.out.println(hexadecimal + " is Invalid");
			return;
		}
		

//		HashMap<String, Integer> map = new HashMap<String, Integer>() {
//			{
//				put("A", 10);
//				put("B", 11);
//				put("C", 12);
//				put("D", 13);
//				put("E", 14);
//				put("F", 15);
//			}
//		};

		StringBuffer sb = new StringBuffer();
		for (int charIter = 0; charIter < hexadecimal.length(); charIter++) {
			sb.append(Integer.parseInt(String.valueOf(hexadecimal.charAt(charIter)), 16));
//			if (map.containsKey(String.valueOf(hexadecimal.charAt(charIter))))
//				sb.append(Integer.parseInt(map.get(String.valueOf(hexadecimal.charAt(charIter))), 16));
//			else
//				sb.append(hexadecimal.charAt(charIter));
		}

//		System.out.println( Integer.parseInt(hex, 16));
	}
}
