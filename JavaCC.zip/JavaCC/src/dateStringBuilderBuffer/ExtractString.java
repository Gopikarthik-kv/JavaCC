package dateStringBuilderBuffer;

import java.util.Scanner;

public class ExtractString {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String fStr = in.nextLine().toLowerCase();
		in.close();
		
		if (fStr.length() < 2) {
			System.out.println("Length of the string " + fStr + " is too low");		
			return;
		}

		if (fStr.length() > 10) {
			System.out.println("Length of the string " + fStr + " is too high");
			return;
		}
		
		if(!fStr.matches("[A-Za-z]+"))
		{
			System.out.println(fStr + " is Invalid");
			return;
		}
		String out = "";
		int strtIndex = 0;
		strtIndex = (fStr.length()) / 2 ;
		out = fStr.substring(strtIndex, fStr.length());
		System.out.println(Character.toUpperCase(out.charAt(0)) + out.substring(1, out.length()));

	}
}
