package ballsBowled;

import java.util.*;

public class UserInterface {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		PlayerBO pb = new PlayerBO();
		List<Integer> playerList = new ArrayList<>();
		pb.setPlayerList(playerList);
		int input = 0;
		do {
			System.out.println("1. Add overs bowled\n2. Number of balls bowled\n3. Exit\nEnter your choice");

			input = Integer.parseInt(sc.nextLine());
			switch (input) {
			case 1:
				System.out.println("Enter the overs bowled");
				pb.addOversDetails(Integer.parseInt(sc.nextLine()));
				break;
			case 2:
				System.out.println("Total number of balls bowled");
				System.out.println(pb.getNoOfBallsBowled());
				break;
			default:
				break;
			}
		} while (input != 3);
		sc.close();

	}

}
