package cc;

import java.time.temporal.ValueRange;
import java.util.Scanner;

public class VideoGame {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the Amount");
		int amnt = Integer.parseInt(in.nextLine());

		if (amnt < 3000) {
			System.out.println(amnt + " is too less");
			in.close();
			return;
		}
		System.out.println("Enter the Video Game Player Type");
		String type = in.nextLine();

		if (!"PS1PS2PS3PS4PS5".contains(type)) {
			System.out.println(type + " is Invalid Type");
			in.close();
			return;
		}
		in.close();
		ValueRange ps1 = ValueRange.of(5000, 7799);
		ValueRange ps2 = ValueRange.of(7800, 9499);
		ValueRange ps3 = ValueRange.of(9500, 11999);
		ValueRange ps4 = ValueRange.of(12000, 14999);
		ValueRange ps5 = ValueRange.of(15000, 19999);

		if (type.equalsIgnoreCase("PS1")) {
			if (ps1.isValidValue(amnt)) {
				System.out.println("You can buy a PS1");
			}

			else {
				System.out.println("You need more amount to buy a PS1");
			}
			return;
		}

		if (type.equalsIgnoreCase("PS2")) {
			if (ps2.isValidValue(amnt)) {
				System.out.println("You can buy a PS2");
			} else {
				System.out.println("You need more amount to buy a PS2");
			}
			return;
		}

		if (type.equalsIgnoreCase("PS3")) {
			if (ps3.isValidValue(amnt)) {
				System.out.println("You can buy a PS3");
			} else {
				System.out.println("You need more amount to buy a PS3");
			}
			return;
		}

		if (type.equalsIgnoreCase("PS4")) {
			if (ps4.isValidValue(amnt)) {
				System.out.println("You can buy a PS4");
			} else {
				System.out.println("You need more amount to buy a PS4");
			}
			return;
		}

		if (type.equalsIgnoreCase("PS5")) {
			if (ps5.isValidValue(amnt)) {
				System.out.println("You can buy a PS5");
			} else {
				System.out.println("You need more amount to buy a PS5");
			}
			return;
		}
	}
}
