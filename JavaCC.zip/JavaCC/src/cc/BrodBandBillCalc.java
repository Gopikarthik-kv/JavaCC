package cc;

import java.util.Scanner;

public class BrodBandBillCalc {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int dataUsg;
		int billAmnt = 500;
		
		dataUsg = Integer.parseInt(in.nextLine());
		if (dataUsg < 0) {
			System.out.printf("%d is not a valid input", dataUsg);
			in.close();
			return;
		}
		in.close();

		if (dataUsg > 1024) {
			billAmnt = billAmnt + 250;
		}

		if (dataUsg > 2048) {

			billAmnt = billAmnt + ((dataUsg - 2048) * 3);
		}
		
		System.out.println(billAmnt);

	}
}
