package abstractClass;

public class TaxableItem extends Item {
	private float GST;
	private float taxAmount;

	public float getGST() {
		return GST;
	}

	public void setGST(float gST) {
		GST = gST;
	}

	public float getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(float taxAmount) {
		this.taxAmount = taxAmount;
	}

	public TaxableItem(String itemName, float itemCost, float GST) {
		super(itemName, itemCost);
		this.GST = GST;
	}

	public TaxableItem() {

	}

	public int findTaxAmount() {
		float itemCost = getItemCost();
		if (itemCost > 0 && GST > 0) {
			setTaxAmount(itemCost * (GST / 100));
			setTotalCost((float) (itemCost + getTaxAmount()));
			return 1;
		} else
			return -1;

	}

}
