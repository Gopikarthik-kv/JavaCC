package cc;

import java.util.HashMap;
import java.util.Scanner;

public class HolidayTrip {

	public static void main(String[] args) {
		HashMap<String, Double> airIndia = new HashMap<String, Double>() {
			{
				put("Travel class", 3200.00);
				put("Economy class", 6950.00);
				put("Business class", 10340.00);
				put("Card Payment", 0.105);
			}
		};

		HashMap<String, Double> spiceJet = new HashMap<String, Double>() {
			{
				put("Travel class", 3450.00);
				put("Economy class", 7945.00);
				put("Business class", 9500.00);
				put("Card Payment", 0.075);
			}
		};

		HashMap<String, Double> goAir = new HashMap<String, Double>() {
			{
				put("Travel class", 3300.00);
				put("Economy class", 7250.00);
				put("Business class", 9890.00);
				put("Card Payment", 0.095);
			}
		};

		HashMap<String, Double> indiGo = new HashMap<String, Double>() {
			{
				put("Travel class", 3490.00);
				put("Economy class", 7560.00);
				put("Business class", 9990.00);
				put("Card Payment", 0.085);
			}
		};

		HashMap<String, HashMap<String, Double>> parentMap = new HashMap<String, HashMap<String, Double>>();
		parentMap.put("Air India", airIndia);
		parentMap.put("Spice Jet", spiceJet);
		parentMap.put("Go Air", goAir);
		parentMap.put("IndiGo", indiGo);

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the flight name");
		String flightName = in.nextLine();

		if (!parentMap.containsKey(flightName)) {
			System.out.println("Filght Name " + flightName + " is not valid");
			in.close();
			return;
		}

		System.out.println("Enter the class");
		String className = in.nextLine();

		if (!parentMap.get(flightName).containsKey(className)) {
			System.out.println("Class Name " + className + " is not valid");
			in.close();
			return;
		}

		System.out.println("Enter the number of seats");
		int numSeats = Integer.parseInt(in.nextLine());
		System.out.println("Card Payment");
		String cardPay = in.nextLine();
		in.close();

		double amount = numSeats * parentMap.get(flightName).get(className);

		if (cardPay.equalsIgnoreCase("Y")) {
			amount = amount - (amount * parentMap.get(flightName).get("Card Payment"));
		}

		if (numSeats > 5 && (flightName.equalsIgnoreCase("IndiGo") || flightName.equalsIgnoreCase("Spice Jet"))) {
			if (numSeats > 10)
				amount = amount - (amount * 0.15);
			else if (numSeats > 5)
				amount = amount - (amount * 0.1);
		}

		System.out.printf("%0f", amount);

	}
}
