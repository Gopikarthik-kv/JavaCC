package abstractClassCC;

public class TeamMember extends User {

	public TeamMember() {

	}

	public TeamMember(String userName, String password, String name, String role) {
		super(userName, password, name, role);
		// TODO Auto-generated constructor stub
	}

	void myRequriements(Requirement[] requirement, String userName) {
		int temp = 0;
		for (Requirement myReq : requirement) {
			if (myReq.getAssignedTo() != null && myReq.getAssignedTo().getUserName().equalsIgnoreCase(userName)) {
				if (temp == 0) {
					System.out.format("%s %s\n", "Id", "Description");
					temp++;
				}
				System.out.format("%s %s\n", myReq.getId(), myReq.getDescription());
			}
		}

		if (temp == 0)
			System.out.println("No records found");
	}
}
