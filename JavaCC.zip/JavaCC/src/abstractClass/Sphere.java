package abstractClass;

public class Sphere extends Shape {
	private int radius;

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	public Sphere(int radius) {
		this.radius = radius;

	}

	@Override
	public double calculateVolume() {
		return (4.0 / 3.0) * Math.PI * Math.pow(this.radius, 3);
	}

}
