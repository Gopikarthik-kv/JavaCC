package cc;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class DecliningSequence {
	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		int arrSize = Integer.parseInt(in.nextLine());

		if (arrSize < 2 || arrSize > 10) {
			System.out.println(arrSize + " is not a valid array element");
			in.close();
			return;
		}

		int[] arr = new int[arrSize];
		Integer[] arrSort = new Integer[arrSize];
		String val = "";
		for (int temp = 0; temp < arrSize; temp++) {
			arr[temp] = Integer.parseInt(in.nextLine());
			arrSort[temp] = arr[temp];
			val = val + arr[temp] + " ";
		}
		in.close();
		Arrays.sort(arrSort, Collections.reverseOrder());
		boolean decOrder = true;
		for (int temp = 0; temp < arrSize; temp++) {
			if (arr[temp] != arrSort[temp])
				decOrder = false;
		}
		Set<Integer> set = new HashSet<Integer>(Arrays.asList(arrSort));
		if (set.size() == 1)
			decOrder = false;

		if (!decOrder)
			System.out.println(val.trim() + " are not in the declining sequential order");
		else
			System.out.println(val.trim() + " are in the declining sequential order");

	}
}
