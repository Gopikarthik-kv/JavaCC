package dateStringBuilderBuffer;

import java.util.Scanner;

public class Changethecase {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String str = in.nextLine();

		if (str.length() < 3) {
			System.out.println("String length of " + str.length() + " is too short");
			in.close();
			return;
		}

		if (str.length() > 10) {
			System.out.println("String length of " + str.length() + " is too long");
			in.close();
			return;
		}

		boolean found = false;
		String resultStr = str;
		for (int iter = 0; iter < str.length(); iter++) {
			if (Character.isAlphabetic(str.charAt(iter))) {
				resultStr = resultStr.replaceFirst(String.valueOf(str.charAt(iter)), "");
			} else
				found = true;
		}

		if (found) {
			System.out.println("String should not contain " + resultStr);
			in.close();
			return;
		}

		char ch = in.nextLine().charAt(0);
		if (str.indexOf(Character.toLowerCase(ch)) < 0 && str.indexOf(Character.toUpperCase(ch)) < 0) {
			System.out.println("Character not found");
			in.close();
			return;
		}

		in.close();

		String resultStr1 = "";
		for (int iter = 0; iter < str.length(); iter++) {
			if ((int) str.charAt(iter) == (int) Character.toUpperCase(ch))
				resultStr1 = resultStr1 + String.valueOf(str.charAt(iter)).toLowerCase();
			else if ((int) str.charAt(iter) == (int) Character.toLowerCase(ch))
				resultStr1 = resultStr1 + String.valueOf(str.charAt(iter)).toUpperCase();
			else
				resultStr1 = resultStr1 + str.charAt(iter);
		}
		System.out.println(resultStr1);
	}
}
//
//import java.util.Scanner;
//
//public class Main {
//public static void main(String[] args) {
//		Scanner in = new Scanner(System.in);
//		String str = in.nextLine();
//
//    	if (str.length() < 3) {
//			System.out.println("String length of " + str.length() + " is too short");
//			in.close();
//			return;
//		}
//
//		if (str.length() > 10) {
//			System.out.println("String length of " + str.length() + " is too long");
//			in.close();
//			return;
//		}
//
//		boolean found = false;
//		String resultStr = "";
//		for (int iter = 0; iter < str.length(); iter++) {
//			if (((int) str.charAt(iter) < 65 || (int) str.charAt(iter) > 90)
//					&& ((int) str.charAt(iter) < 97 || (int) str.charAt(iter) > 122) || found) {
//				found = true;
//				resultStr = resultStr + str.charAt(iter);
//			}
//		}
//
//		if (found) {
//			System.out.println("String should not contain " + resultStr);
//			in.close();
//			return;
//		}
//		char ch = in.nextLine().charAt(0);
//		if (str.indexOf(Character.toLowerCase(ch)) < 0 && str.indexOf(Character.toUpperCase(ch)) < 0 ) {
//			System.out.println("Character not found");
//			in.close();
//			return;
//		}
//
//		in.close();
//
//		String resultStr1 = "";
//		for (int iter = 0; iter < str.length(); iter++) {
//			if ((int) str.charAt(iter) > 64 && (int) str.charAt(iter) < 91
//					&& (int)str.charAt(iter) == (int) Character.toUpperCase(ch))
//				resultStr1 = resultStr1 + String.valueOf(str.charAt(iter)).toLowerCase();
//			else if ((int) str.charAt(iter) > 96 && (int) str.charAt(iter) < 123
//					&&  (int) str.charAt(iter) == (int) Character.toLowerCase(ch))
//				resultStr1 = resultStr1 + String.valueOf(str.charAt(iter)).toUpperCase();
//			else
//				resultStr1 = resultStr1 + str.charAt(iter);
//		}
//		System.out.println(resultStr1);
//	}
//}
