package abstractClass;

//import java.util.Scanner;

//
//public class Main {
//
//	public static void main(String[] args) {
//
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the Item Name:");
//		String pname = sc.nextLine();
//		System.out.println("Enter the Item Cost:");
//		float cost = sc.nextFloat();
//		System.out.println("Enter the GST:");
//		float GST = sc.nextFloat();
//		sc.close();
//		TaxableItem taxItem = new TaxableItem(pname, cost, GST);
//		if (taxItem.findTaxAmount() > 0)
//			System.out.printf("Total Cost:%.2f", taxItem.getTotalCost());
//		else
//			System.out.println(-1);
//
//	}
//}

//import java.util.Scanner;
//
//public class Main {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter the ISBN Number");
//		int isbnnum = sc.nextInt();
//		sc.nextLine();
//		System.out.println("Enter the Book Name");
//		String name = sc.nextLine();
//		System.out.println("Enter the price");
//		double price = sc.nextDouble();
//		System.out.println("Enter the magazine Type");
//		String type = sc.next();
//		sc.close();
//
//		Magazine magazine = new Magazine(isbnnum, name, price, type);
//		double discount = magazine.calculateDiscount();
//		System.out.println("ISBN Number " + isbnnum);
//		System.out.println("Discount Amount " + discount);
//
//	}
//
//}

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name:");
		String name = sc.nextLine();
		System.out.println("Enter the salary:");
		float sal = sc.nextFloat();
		System.out.println("Enter the pfpercentage:");
		float pf = sc.nextFloat();
		sc.close();
		PermanentEmployee pEmp = new PermanentEmployee();
		if (PermanentEmployee.validateInput(sal, pf)) {
			pEmp = new PermanentEmployee(name, sal, pf);
			pEmp.findNetSalary();
			System.out.println("Employee Name:" + pEmp.getName());
			System.out.printf("PF Amount:%.2f\n", pEmp.getPfamount());
			System.out.printf("Netsalary:%.2f", pEmp.getNetsalary());
		} else {
			System.out.println("Error!!!  Unable to calculate the NetSalary.");
		}
	}

}
