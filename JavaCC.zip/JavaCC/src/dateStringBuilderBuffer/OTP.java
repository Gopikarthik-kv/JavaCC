package dateStringBuilderBuffer;

import java.util.Scanner;

public class OTP {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String inStr = sc.nextLine();
		sc.close();

		int charInter = 0;

		int otpStart = inStr.toUpperCase().indexOf("OTP") + 3;
		if (otpStart < 0) {
			System.out.println("OTP not available");
		}

		StringBuffer sb = new StringBuffer();
		do {
			otpStart = inStr.toUpperCase().indexOf("OTP");
			if (otpStart > -1)
				otpStart = otpStart + 3;
			else
				break;

			charInter = charInter + otpStart;
			inStr = inStr.trim().substring(otpStart, inStr.length()).toUpperCase().trim();

			for (int charIter = 0; charIter < inStr.length(); charIter++) {

				if (!Character.isDigit(inStr.charAt(charIter)))
					break;
				else
					sb.append(inStr.charAt(charIter));
				charInter++;
			}

			if (sb.length() == 6)
				break;

		} while (charInter != inStr.length());

		if (sb.length() != 6) {
			System.out.println("OTP not available");
		} else
			System.out.println(sb);

	}

}

//
//import java.util.*;
//public class Main {
//	public static void main(String[] args)
//	{
//			Scanner sc = new Scanner(System.in);
//		String inStr = sc.nextLine();
//		sc.close();
//
//		int otpStart = inStr.toUpperCase().indexOf("OTP") + 3;
//		if (otpStart < 0) {
//			System.out.println("OTP not available");
//		}
//
////	int last = 10;
////	if(inStr.length() < 10)
////		last = 
//
//		inStr = inStr.trim().substring(otpStart, inStr.length()).toUpperCase();
//		inStr = inStr.replace("OTP", "");
//		if (inStr.contains("OTP")) {
//			inStr = inStr.substring(inStr.indexOf("OTP") + 3, inStr.length());
//		}
//		inStr = inStr.trim();
//		StringBuffer sb = new StringBuffer();
//		if (inStr.length() < 6) {
//			System.out.println("OTP not available");
//			return;
//		}
//
//		for (int charIter = 0; charIter < inStr.length(); charIter++) {
//
//			if (!Character.isDigit(inStr.charAt(charIter)))
//				break;
//			else
//				sb.append(inStr.charAt(charIter));
//
//		}
//
//		if (sb.length() != 6) {
//			System.out.println("OTP not available");
//		} else
//			System.out.println(sb);
//
//		sc.close();
//	}
//
//}
