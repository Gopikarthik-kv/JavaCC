package gradeCalculation;

import java.util.stream.IntStream;

public class GradeCalculator extends Thread {
	private String studName;

	private char result;

	private int[] marks;

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public char getResult() {
		 result = 'E';
		int sum = IntStream.of(marks).sum();
		if (sum > 399 && sum < 501)
			result = 'A';
		else if (sum > 299 && sum < 400)
			result = 'B';
		else if (sum > 199 && sum < 300)
			result = 'B';
		return result;
	}

	public void setResult(char result) {
		this.result = result;
	}

	public int[] getMarks() {
		return marks;
	}

	public void setMarks(int[] marks) {
		this.marks = marks;
	}

	public GradeCalculator(String studName, int[] marks) {
		this.studName = studName;
		this.marks = marks;

	}

	public void run() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
