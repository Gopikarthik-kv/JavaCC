package backAccountDetails;

import java.util.Scanner;

public class AccountDetails {

//	public static Account acc;
	Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccountDetails ac = new AccountDetails();
		Account acc = ac.getAccountDetails();
		if(acc.withdraw(ac.getWithdrawAmount()))
			return;
	}

	public Account getAccountDetails() {
		Account acc = new Account();
		System.out.println("Enter account id:");
		acc.setAccountId(Integer.parseInt(in.nextLine()));
		System.out.println("Enter account type:");
		acc.setAccountType(in.nextLine());
		int balance = 0;
		do {
			System.out.println("Enter balance:");
			balance = Integer.parseInt(in.nextLine());
			if (balance < 1)
				System.out.println("Balance should be positive");
			else {
				acc.setBalance(balance);
//				break;
			}
		} while (balance < 1);

		
		return acc;

	}

	public int getWithdrawAmount() {
		Scanner in = new Scanner(System.in);
		int withAmnt = 0;
		do {
			System.out.println("Enter amount to be withdrawn:");
			withAmnt = Integer.parseInt(in.nextLine());
			if (withAmnt < 1)
				System.out.println("Amount should be positive");
			else
				break;

		} while (withAmnt < 1);

		in.close();
		return withAmnt;
	}

}
